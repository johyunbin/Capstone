/* global React */
const { useState, useEffect } = React;

// ─── Type scale & spacing (1280×720 baseline, scale ×0.67 of 1920) ───
const TYPE_SCALE = {
  display: 96,
  h1: 56,
  h2: 36,
  h3: 26,
  subtitle: 22,
  body: 16,
  bodyLg: 18,
  meta: 14,
  caption: 12,
  eyebrow: 11,
};
const SPACING = {
  paddingTop: 56,
  paddingBottom: 44,
  paddingX: 72,
  titleGap: 24,
  itemGap: 16,
};
const RED = "var(--brand-red)";
const INK = "var(--ink)";
const FG1 = "var(--fg1)";
const FG2 = "var(--fg2)";
const FG3 = "var(--fg3)";
const LINE = "var(--line)";

// ─── Shared chrome ────────────────────────────────────────────
function SlideChrome({ secn, title, page, total = 22, children, dark }) {
  const fg = dark ? "#FAFAF9" : "var(--fg1)";
  const lineCol = dark ? "rgba(255,255,255,0.12)" : "var(--line)";
  return (
    <>
      <div style={{ width: 158, height: 2, background: RED, marginBottom: 6 }} />
      <div
        style={{
          fontSize: TYPE_SCALE.eyebrow,
          fontWeight: 700,
          letterSpacing: "0.16em",
          textTransform: "uppercase",
          color: RED,
        }}
      >
        CAPSTONE 2026‑1 / MIDTERM PRESENTATION / 연세대학교
      </div>
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "baseline",
          marginTop: 22,
          paddingBottom: 14,
          borderBottom: `1px solid ${lineCol}`,
          gap: 16,
        }}
      >
        <div style={{ display: "flex", alignItems: "baseline", gap: 8, minWidth: 0 }}>
          {secn && (
            <span style={{ fontSize: TYPE_SCALE.meta, fontWeight: 700, color: RED }}>
              {secn}
            </span>
          )}
          <span
            style={{
              fontSize: TYPE_SCALE.h3,
              fontWeight: 700,
              color: fg,
              letterSpacing: "-0.01em",
            }}
          >
            {title}
          </span>
        </div>
        <div style={{ fontFamily: "var(--font-mono)", fontSize: 13, color: FG3, flexShrink: 0, whiteSpace: "nowrap" }}>
          {page} / {total}
        </div>
      </div>
      <div style={{ flex: 1, paddingTop: 22, minHeight: 0, display: "flex", flexDirection: "column" }}>
        {children}
      </div>
      <div
        style={{
          position: "absolute",
          left: SPACING.paddingX,
          right: SPACING.paddingX,
          bottom: 18,
          display: "flex",
          justifyContent: "space-between",
          fontFamily: "var(--font-mono)",
          fontSize: TYPE_SCALE.eyebrow,
          color: FG3,
          paddingTop: 8,
          borderTop: `1px solid ${lineCol}`,
        }}
      >
        <span style={{ whiteSpace: "nowrap" }}>속도는벡터 · 박세은 · 강재현 · 조현빈 · 이동욱</span>
        <span style={{ whiteSpace: "nowrap" }}>2026‑04‑30 · 지도교수 박광현 · 연구원 임채림</span>
      </div>
    </>
  );
}

// ─── Eyebrow tag (small, used inside slide bodies) ────────────
function Eyebrow({ children, color = RED, mb = 12 }) {
  return (
    <div
      style={{
        fontSize: TYPE_SCALE.eyebrow,
        fontWeight: 700,
        letterSpacing: "0.14em",
        textTransform: "uppercase",
        color,
        marginBottom: mb,
      }}
    >
      {children}
    </div>
  );
}

function Quote({ children, mt = 24 }) {
  return (
    <blockquote
      style={{
        marginTop: mt,
        marginBottom: 0,
        marginLeft: 0,
        marginRight: 0,
        borderLeft: `3px solid ${RED}`,
        background: "var(--bg2)",
        padding: "12px 20px",
        fontSize: TYPE_SCALE.bodyLg,
        color: FG1,
        lineHeight: 1.55,
      }}
    >
      {children}
    </blockquote>
  );
}

// ─── 1. Cover ─────────────────────────────────────────────────
function Cover() {
  return (
    <>
      <div style={{ width: 158, height: 2, background: RED, marginBottom: 6 }} />
      <div
        style={{
          fontSize: TYPE_SCALE.eyebrow,
          fontWeight: 700,
          letterSpacing: "0.16em",
          textTransform: "uppercase",
          color: RED,
        }}
      >
        CAPSTONE 2026‑1 / MIDTERM PRESENTATION / 연세대학교
      </div>
      <div style={{ flex: 1, display: "flex", flexDirection: "column", justifyContent: "center" }}>
        <div style={{ fontSize: TYPE_SCALE.body, color: FG3, marginBottom: 14, fontFamily: "var(--font-mono)" }}>
          속도는벡터 · 2026‑04‑30
        </div>
        <h1
          style={{
            fontSize: TYPE_SCALE.h1,
            lineHeight: 1.1,
            letterSpacing: "-0.02em",
            maxWidth: 1040,
            marginBottom: 32,
            fontWeight: 700,
          }}
        >
          <span style={{ color: INK }}>Skew‑Aware Stratified Sampling</span>
          <span style={{ color: FG2 }}> 을 이용한</span>
          <br />
          <span style={{ color: INK }}>Vector Cardinality</span>
          <span style={{ color: FG2 }}> 추정 정확도 개선 연구</span>
        </h1>
        <div style={{ display: "flex", gap: 56, alignItems: "flex-end", marginTop: 8 }}>
          <div>
            <Eyebrow mb={6}>팀</Eyebrow>
            <div style={{ fontSize: 24, fontWeight: 800, letterSpacing: "-0.01em" }}>속도는벡터</div>
            <div style={{ fontSize: 14, color: FG2, marginTop: 6 }}>
              박세은 (팀장) · 강재현 · 조현빈 · 이동욱
            </div>
          </div>
          <div style={{ borderLeft: `1px solid ${LINE}`, paddingLeft: 28 }}>
            <Eyebrow mb={6}>지도</Eyebrow>
            <div style={{ fontSize: 14, color: FG1 }}>박광현 교수 · BDAI 연구실</div>
            <div style={{ fontSize: 14, color: FG2, marginTop: 2 }}>임채림 연구원 · 박성원 멘토</div>
          </div>
          <div style={{ borderLeft: `1px solid ${LINE}`, paddingLeft: 28 }}>
            <Eyebrow mb={6}>분석 대상</Eyebrow>
            <div style={{ fontSize: 14, color: FG1 }}>Exqutor</div>
            <div style={{ fontSize: 12, color: FG3, marginTop: 2, fontFamily: "var(--font-mono)" }}>
              arXiv:2512.09695v2
            </div>
          </div>
        </div>
      </div>
      <div
        style={{
          position: "absolute",
          left: SPACING.paddingX,
          right: SPACING.paddingX,
          bottom: 18,
          display: "flex",
          justifyContent: "space-between",
          fontFamily: "var(--font-mono)",
          fontSize: 11,
          color: FG3,
          paddingTop: 8,
          borderTop: `1px solid ${LINE}`,
        }}
      >
        <span style={{ whiteSpace: "nowrap" }}>인종 A428 · 4월 30일</span>
        <span style={{ whiteSpace: "nowrap" }}>중간발표 · 10분</span>
      </div>
    </>
  );
}

// ─── 2. TOC ───────────────────────────────────────────────────
function TOC() {
  const items = [
    ["01", "Problem", "Vector Cardinality Estimation 의 사각지대", "04"],
    ["02", "Background", "Exqutor — 방법론과 한계", "06"],
    ["03", "Our Approach", "Skew‑Aware Stratified Sampling", "09"],
    ["04", "Experiments", "RQ1 · RQ2 · RQ3 — 설계와 결과", "12"],
    ["05", "Plan", "현재 진행 상황과 향후 계획", "19"],
  ];
  return (
    <SlideChrome title="Table of Contents" page="02">
      <div style={{ display: "grid", gridTemplateColumns: "72px 1fr 100px", columnGap: 24 }}>
        {items.map((it, i) => (
          <React.Fragment key={i}>
            <div
              style={{
                padding: "20px 0",
                borderTop: i === 0 ? `2px solid ${INK}` : `1px solid ${LINE}`,
                borderBottom: i === items.length - 1 ? `2px solid ${INK}` : "none",
                fontFamily: "var(--font-mono)",
                fontSize: 26,
                fontWeight: 700,
                color: RED,
              }}
            >
              {it[0]}
            </div>
            <div
              style={{
                padding: "20px 0",
                borderTop: i === 0 ? `2px solid ${INK}` : `1px solid ${LINE}`,
                borderBottom: i === items.length - 1 ? `2px solid ${INK}` : "none",
              }}
            >
              <div style={{ fontSize: 26, fontWeight: 700, color: INK }}>{it[1]}</div>
              <div style={{ fontSize: 14, color: FG3, marginTop: 2 }}>{it[2]}</div>
            </div>
            <div
              style={{
                padding: "20px 0",
                borderTop: i === 0 ? `2px solid ${INK}` : `1px solid ${LINE}`,
                borderBottom: i === items.length - 1 ? `2px solid ${INK}` : "none",
                fontFamily: "var(--font-mono)",
                fontSize: 14,
                color: FG3,
                alignSelf: "center",
              }}
            >
              p. {it[3]}
            </div>
          </React.Fragment>
        ))}
      </div>
    </SlideChrome>
  );
}

// ─── Section divider ──────────────────────────────────────────
function SectionDivider({ num, title, subtitle, page }) {
  return (
    <div style={{ position: "absolute", inset: 0, display: "flex", flexDirection: "column", padding: `${SPACING.paddingTop}px ${SPACING.paddingX}px ${SPACING.paddingBottom}px`, background: "#FAFAF9" }}>
      <div style={{ width: 158, height: 2, background: RED, marginBottom: 6 }} />
      <div style={{ fontSize: TYPE_SCALE.eyebrow, fontWeight: 700, letterSpacing: "0.16em", textTransform: "uppercase", color: RED }}>
        CAPSTONE 2026‑1 / MIDTERM PRESENTATION / 연세대학교
      </div>
      <div style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "flex-start" }}>
        <div style={{ display: "grid", gridTemplateColumns: "auto 1fr", columnGap: 48, alignItems: "baseline", maxWidth: 980 }}>
          <div
            style={{
              fontFamily: "var(--font-mono)",
              fontSize: 132,
              fontWeight: 700,
              color: RED,
              letterSpacing: "-0.04em",
              lineHeight: 0.9,
            }}
          >
            {num}
          </div>
          <div>
            <div style={{ fontSize: 56, fontWeight: 800, color: INK, letterSpacing: "-0.02em", lineHeight: 1.05 }}>{title}</div>
            <div style={{ fontSize: 22, color: FG2, marginTop: 16, lineHeight: 1.4, maxWidth: 700 }}>{subtitle}</div>
          </div>
        </div>
      </div>
      <div style={{ display: "flex", justifyContent: "space-between", fontFamily: "var(--font-mono)", fontSize: 11, color: FG3, paddingTop: 8, borderTop: `1px solid ${LINE}` }}>
        <span style={{ whiteSpace: "nowrap" }}>속도는벡터 · 박세은 · 강재현 · 조현빈 · 이동욱</span>
        <span style={{ whiteSpace: "nowrap" }}>{page} / 22</span>
      </div>
    </div>
  );
}

// ─── 4. Problem ───────────────────────────────────────────────
function Problem() {
  return (
    <SlideChrome secn="1." title="Problem — Vector Cardinality 추정의 사각지대" page="04">
      <div style={{ fontSize: TYPE_SCALE.body, color: FG2, marginBottom: 24, maxWidth: 980, lineHeight: 1.55 }}>
        벡터 range 조건의 선택도는 query 마다 크게 달라지지만, 기존 optimizer 는 벡터 공간 분포를 반영하지 못한다.
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 32 }}>
        <div>
          <Eyebrow mb={14}>기존 시스템 — 고정 비율 추정</Eyebrow>
          {[
            ["pgvector", "33.3%", "fixed estimator"],
            ["VBASE", "50.0%", "fixed estimator"],
            ["DuckDB", "100%", "scan all rows"],
          ].map(([n, v, d]) => (
            <div
              key={n}
              style={{
                display: "flex",
                alignItems: "baseline",
                justifyContent: "space-between",
                padding: "16px 0",
                borderBottom: `1px solid ${LINE}`,
              }}
            >
              <div style={{ fontSize: 18, fontWeight: 700 }}>{n}</div>
              <div style={{ display: "flex", alignItems: "baseline", gap: 14 }}>
                <span
                  style={{
                    fontFamily: "var(--font-num)",
                    fontSize: 34,
                    fontWeight: 700,
                    color: RED,
                    fontFeatureSettings: '"tnum" 1',
                  }}
                >
                  {v}
                </span>
                <span style={{ fontSize: 12, color: FG3 }}>{d}</span>
              </div>
            </div>
          ))}
        </div>
        <div>
          <Eyebrow mb={14}>실제 — query 마다 달라지는 분포</Eyebrow>
          <ul style={{ margin: 0, paddingLeft: 0, listStyle: "none", fontSize: 15, lineHeight: 1.7, display: "flex", flexDirection: "column", gap: 8 }}>
            <li>
              <span style={{ color: RED, marginRight: 8 }}>■</span>
              실제 선택도는 query 에 따라{" "}
              <b style={{ color: RED }}>0.001% ~ 100%</b> 의 광범위한 분포
            </li>
            <li>
              <span style={{ color: RED, marginRight: 8 }}>■</span>
              잘못된 cardinality 추정 → join 순서, index 사용, scan 전략 선택 왜곡
            </li>
            <li>
              <span style={{ color: RED, marginRight: 8 }}>■</span>
              결과적으로 비효율적 실행 계획 채택
            </li>
          </ul>
          <Quote mt={24}>
            고정 비율 추정으로는 <b>query‑dependent vector selectivity</b> 를 설명할 수 없다.
          </Quote>
        </div>
      </div>
    </SlideChrome>
  );
}

// ─── 6. Background — Exqutor methods ─────────────────────────
function Background() {
  const items = [
    {
      tag: "ECQO",
      sub: "(Exact Cardinality Query Optimization)",
      cond: "HNSW 인덱스가 있을 때",
      body: "실행 계획 단계에서 HNSW range query 를 직접 실행하여 정확한 cardinality 산출.",
      big: "1~2 ms",
      desc: "단시간 내 정확한 cardinality 획득",
    },
    {
      tag: "Adaptive Sampling",
      sub: "(Momentum‑based)",
      cond: "HNSW 인덱스가 없을 때",
      body: "sample size 를 조금씩 늘려가며 cardinality 를 근사하는 dynamic uniform sampling.",
      big: "~3.2×",
      desc: "No‑index VAQ 성능 개선",
    },
  ];
  return (
    <SlideChrome secn="2‑1." title="Background — Exqutor 의 두 갈래 방법론" page="06">
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 32 }}>
        {items.map((x, i) => (
          <div key={i} style={{ border: `1px solid ${LINE}`, padding: 28 }}>
            <Eyebrow mb={6}>{x.cond}</Eyebrow>
            <div style={{ fontSize: 26, fontWeight: 700, marginTop: 6 }}>{x.tag}</div>
            <div style={{ fontSize: 13, color: FG3, marginTop: 2 }}>{x.sub}</div>
            <p style={{ fontSize: 14, color: FG2, marginTop: 18, marginBottom: 20, lineHeight: 1.6 }}>{x.body}</p>
            <div style={{ display: "flex", alignItems: "baseline", gap: 12, paddingTop: 14, borderTop: `1px solid ${LINE}` }}>
              <span style={{ fontFamily: "var(--font-num)", fontSize: 44, fontWeight: 700, color: RED, fontFeatureSettings: '"tnum" 1', letterSpacing: "-0.02em" }}>
                {x.big}
              </span>
              <span style={{ fontSize: 13, color: FG2 }}>{x.desc}</span>
            </div>
          </div>
        ))}
      </div>
      <Quote mt={24}>
        → No‑index sampling path 에서 uniform sample 이 <b>skewed vector distribution</b> 을 대표할 수 있는가?
      </Quote>
    </SlideChrome>
  );
}

// ─── 7. vector.c diff ─────────────────────────────────────────
function VectorC() {
  return (
    <SlideChrome secn="2‑2." title="Background — Adaptive Sampling 의 vector.c 한계" page="07">
      <div style={{ display: "grid", gridTemplateColumns: "1.05fr 1fr", gap: 28 }}>
        <div
          style={{
            background: "#0A0A0A",
            color: "#F5F5F4",
            padding: "18px 22px",
            fontFamily: "var(--font-mono)",
            fontSize: 12.5,
            lineHeight: 1.65,
            borderRadius: 2,
          }}
        >
          <div style={{ color: "#F87171", marginBottom: 8 }}>// Pivot A — Hook trigger (line 243)</div>
          <div style={{ color: "#FCA5A5" }}>- if (table_count &gt; 2)</div>
          <div style={{ color: "#86EFAC" }}>+ if (table_count &gt;= 1)</div>
          <div style={{ color: "#737373" }}>&nbsp;&nbsp;# 단일 테이블 query 에도 hook 활성화</div>
          <div style={{ height: 12 }} />
          <div style={{ color: "#F87171", marginBottom: 8 }}>// Pivot B — Sampling method (line 889)</div>
          <div style={{ color: "#FCA5A5" }}>- TABLESAMPLE <span style={{ color: "#FDA4AF" }}>SYSTEM</span>(%f)</div>
          <div style={{ color: "#86EFAC" }}>+ TABLESAMPLE <span style={{ color: "#FDA4AF" }}>BERNOULLI</span>(%f)</div>
          <div style={{ color: "#737373" }}>&nbsp;&nbsp;# 블록 단위 → 행 단위 (skew 내성↑)</div>
          <div style={{ height: 12 }} />
          <div style={{ color: "#F87171", marginBottom: 8 }}>// Pivot C — Stratified sampling branch</div>
          <div style={{ color: "#FCA5A5" }}>- (no stratification logic)</div>
          <div style={{ color: "#86EFAC" }}>+ +228 lines: KM20 strata → per‑stratum BERN → HT</div>
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          {[
            ["#1", "Hook Trigger 누락", "table_count>2 조건으로 single vector range query 는 AS 미진입 → pgvector default 1/3 로 fallback."],
            ["#2", "Gate Relaxation 만으로 부족", "Hook 완화 시 추정용 TABLESAMPLE 이 실제 plan 에도 반영 → SELECT count(*) 결과가 sample 기준."],
            ["#3", "Block‑level sampling bias", "SYSTEM 은 page/block 단위 → row‑level uniform 보장 X. skewed vector space 에서 대표성 저하."],
          ].map(([n, t, b]) => (
            <div key={n} style={{ borderLeft: `3px solid ${RED}`, paddingLeft: 14 }}>
              <div style={{ fontFamily: "var(--font-mono)", fontSize: 11, color: RED, fontWeight: 700 }}>{n}</div>
              <div style={{ fontSize: 15, fontWeight: 700, marginTop: 2 }}>{t}</div>
              <div style={{ fontSize: 12.5, color: FG2, marginTop: 4, lineHeight: 1.55 }}>{b}</div>
            </div>
          ))}
        </div>
      </div>
      <Quote mt={18}>
        ★ 단일 테이블 range query 에는 실행 plan 을 바꾸지 않는 <b>estimation‑only sampling 경로</b> 가 필요하다.
      </Quote>
    </SlideChrome>
  );
}

// ─── 9. Approach ──────────────────────────────────────────────
function Approach() {
  return (
    <SlideChrome secn="3‑1." title="Approach — Skew‑Aware Stratified Sampling 제안" page="09">
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 40, alignItems: "start" }}>
        <div>
          <Eyebrow mb={8} color={FG3}>기존 연구</Eyebrow>
          <div style={{ fontSize: 22, fontWeight: 700, color: FG2 }}>Uniform Adaptive Sampling</div>
          <div style={{ height: 1, background: LINE, margin: "20px 0" }} />
          <Eyebrow mb={8}>제안</Eyebrow>
          <div style={{ fontSize: 28, fontWeight: 800, color: INK, letterSpacing: "-0.01em" }}>
            Skew‑Aware Stratified Sampling
          </div>
          <div style={{ fontFamily: "var(--font-mono)", fontSize: 16, color: RED, marginTop: 14, fontWeight: 600 }}>
            SYSTEM → BERN → KM20
          </div>
        </div>
        <div>
          <Eyebrow mb={14}>핵심 기여</Eyebrow>
          <ul style={{ margin: 0, padding: 0, listStyle: "none", display: "flex", flexDirection: "column", gap: 14, fontSize: 14.5, lineHeight: 1.6 }}>
            <li>
              <b style={{ color: RED }}>① Target.</b> 단일 테이블 vector range query 의 no‑index sampling path
            </li>
            <li>
              <b style={{ color: RED }}>② Decomposition.</b> block‑level sampling bias / spatial skew 를 분리하여 다룬다
            </li>
            <li>
              <b style={{ color: RED }}>③ Validation.</b> RANDOM20 / Two‑Level 분해로 spatial‑aware 효과를 정량화
            </li>
          </ul>
        </div>
      </div>
      <Quote mt={32}>
        ✦ 본 연구는 <b>block bias 를 제거</b>한 뒤 skewed vector space 에서 <b>sample allocation 을 재설계</b> 한다.
      </Quote>
    </SlideChrome>
  );
}

// ─── 10. Contributions ────────────────────────────────────────
function Contributions() {
  const items = [
    ["①", "문제 정의", "Hook 누락 + block bias 라는 두 층위의 문제를 분리해 정의했다.", "vector.c line 243 / 889"],
    ["②", "Skew‑Aware Stratified Sampling", "K‑means 20‑strata + per‑stratum BERN + HT 추정량을 도입했다.", "+228 lines, estimation‑only 경로"],
    ["③", "통계적 검증", "5‑seed × 100 query × 6 selectivity, 95% CI 로 효과를 정량화했다.", "DEEP 1M / DEEP 8M / SIFT 1.5M"],
  ];
  return (
    <SlideChrome secn="3‑2." title="Contributions — 본 연구의 세 가지 기여" page="10">
      <div style={{ display: "flex", flexDirection: "column", gap: 0 }}>
        {items.map((r, i) => (
          <div
            key={i}
            style={{
              display: "grid",
              gridTemplateColumns: "60px 1fr 280px",
              columnGap: 28,
              padding: "26px 0",
              borderTop: i === 0 ? `2px solid ${INK}` : `1px solid ${LINE}`,
              borderBottom: i === items.length - 1 ? `2px solid ${INK}` : "none",
              alignItems: "baseline",
            }}
          >
            <div style={{ fontFamily: "var(--font-num)", fontSize: 36, fontWeight: 700, color: RED, letterSpacing: "-0.02em" }}>
              {r[0]}
            </div>
            <div>
              <div style={{ fontSize: 22, fontWeight: 700, color: INK, letterSpacing: "-0.01em" }}>{r[1]}</div>
              <div style={{ fontSize: 14, color: FG2, marginTop: 6, lineHeight: 1.55 }}>{r[2]}</div>
            </div>
            <div style={{ fontFamily: "var(--font-mono)", fontSize: 12, color: FG3, lineHeight: 1.5 }}>{r[3]}</div>
          </div>
        ))}
      </div>
    </SlideChrome>
  );
}

// ─── 12. RQ1 ──────────────────────────────────────────────────
function RQ1Heatmap() {
  return (
    <SlideChrome secn="4‑1." title="RQ1 — Query‑side Skew 지표는 Q‑error 를 설명하지 못했다" page="12">
      <div style={{ display: "grid", gridTemplateColumns: "1.2fr 1fr", gap: 28 }}>
        <figure style={{ margin: 0, border: `1px solid ${LINE}`, padding: 8, alignSelf: "start" }}>
          <img src="assets/figures/phase5_heatmap.png" alt="Phase 5 heatmap" style={{ width: "100%", display: "block" }} />
          <figcaption style={{ fontSize: 10.5, color: FG3, marginTop: 6 }}>
            Phase 5 — 로컬 4 지표 × 6 selectivity, 24 조합 모두 |ρ|&lt;0.2
          </figcaption>
        </figure>
        <div>
          <Eyebrow mb={10}>실험 셋업</Eyebrow>
          <table style={{ fontSize: 12, width: "100%", borderCollapse: "collapse" }}>
            <tbody>
              <tr><td style={{ padding: "5px 0", color: FG3, width: 90 }}>데이터셋</td><td>DEEP 1M subset · 96d</td></tr>
              <tr><td style={{ padding: "5px 0", color: FG3 }}>쿼리</td><td>100 query × 6 selectivity × 5‑seed = 3000</td></tr>
              <tr><td style={{ padding: "5px 0", color: FG3 }}>글로벌</td><td>Fisher γ, tail ratio, P99/P50, skewness</td></tr>
              <tr><td style={{ padding: "5px 0", color: FG3 }}>로컬</td><td>k‑NN entropy, PCA EVR1, KDE modality, NN clustering</td></tr>
            </tbody>
          </table>
          <Eyebrow mb={10}>주요 발견</Eyebrow>
          <ul style={{ margin: 0, padding: 0, listStyle: "none", display: "flex", flexDirection: "column", gap: 10, fontSize: 13.5, lineHeight: 1.55 }}>
            <li><span style={{ color: RED, fontWeight: 700, marginRight: 6 }}>①</span> 글로벌·로컬 지표 모두 Q‑error 와 안정적 상관 없음</li>
            <li><span style={{ color: RED, fontWeight: 700, marginRight: 6 }}>②</span> 24 조합 모두 Spearman |ρ| &lt; 0.2</li>
            <li><span style={{ color: RED, fontWeight: 700, marginRight: 6 }}>③</span> query‑side feature 만으로 sampling layer 결정 불가</li>
          </ul>
        </div>
      </div>
    </SlideChrome>
  );
}

// ─── 13. RQ2(1) ───────────────────────────────────────────────
function RQ2Table() {
  const rows = [
    ["0.001", "2.597", "2.597", "+0.0", "0.596", "6/8", false],
    ["0.010", "1.558", "1.299", "+20.0", "0.240", "45/40", true],
    ["0.050", "1.203", "1.195", "+0.7", "0.0009", "58/37", false],
    ["0.100", "1.212", "1.132", "+7.0", "<0.001", "66/31", true],
    ["0.300", "1.210", "1.079", "+12.0", "<0.001", "76/24", true],
    ["0.500", "1.153", "1.052", "+9.6", "<0.001", "78/22", true],
  ];
  return (
    <SlideChrome secn="4‑2." title="RQ2(1) — Block‑level SYSTEM vs Row‑level BERN" page="13">
      <div style={{ display: "grid", gridTemplateColumns: "1.1fr 1fr", gap: 30 }}>
        <div>
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
            <thead>
              <tr style={{ borderBottom: `2px solid ${INK}` }}>
                {["select", "SYS (block)", "BERN (row)", "diff%", "p‑value", "행 우위"].map(h => (
                  <th key={h} style={{ padding: "8px 10px", textAlign: "left", color: FG2 }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody style={{ fontFamily: "var(--font-num)", fontFeatureSettings: '"tnum" 1' }}>
              {rows.map(r => (
                <tr key={r[0]} style={{ borderBottom: `1px solid ${LINE}` }}>
                  <td style={{ padding: "9px 10px", fontFamily: "var(--font-sans)", color: FG2 }}>{r[0]}</td>
                  <td style={{ padding: "9px 10px" }}>{r[1]}</td>
                  <td style={{ padding: "9px 10px" }}>{r[2]}</td>
                  <td style={{ padding: "9px 10px", color: r[6] ? RED : FG2, fontWeight: r[6] ? 700 : 400 }}>{r[3]}</td>
                  <td style={{ padding: "9px 10px", color: FG3 }}>{r[4]}</td>
                  <td style={{ padding: "9px 10px" }}>{r[5]}</td>
                </tr>
              ))}
            </tbody>
          </table>
          <div style={{ fontSize: 11, color: FG3, marginTop: 8 }}>표: Q‑error median · paired Wilcoxon · 100 query.</div>
        </div>
        <div>
          <Eyebrow mb={10}>Takeaways</Eyebrow>
          <ul style={{ margin: 0, padding: 0, listStyle: "none", display: "flex", flexDirection: "column", gap: 12, fontSize: 13.5, lineHeight: 1.55 }}>
            <li><span style={{ color: RED, fontWeight: 700, marginRight: 6 }}>①</span> s=0.05~0.5 에서 BERN 이 SYSTEM 보다 일관되게 낮은 Q‑error</li>
            <li><span style={{ color: RED, fontWeight: 700, marginRight: 6 }}>②</span> s=0.5: median 1.1527 → 1.0519, <b style={{ color: RED }}>+9.6%</b>, 78/100 query 개선</li>
            <li><span style={{ color: RED, fontWeight: 700, marginRight: 6 }}>③</span> low selectivity 에서는 true cardinality 가 작아 Q‑error 변동이 큼</li>
          </ul>
          <figure style={{ margin: "20px 0 0", border: `1px solid ${LINE}`, padding: 6 }}>
            <img src="assets/figures/figure_1_phase4_scatter.png" alt="phase4 scatter" style={{ width: "100%", display: "block" }} />
            <figcaption style={{ fontSize: 10, color: FG3, marginTop: 4 }}>Fig 1 — SYS vs BERN paired Q‑error scatter</figcaption>
          </figure>
        </div>
      </div>
    </SlideChrome>
  );
}

// ─── 14. RQ2(2) ───────────────────────────────────────────────
function RQ2KM20() {
  const rows = [
    ["50%", "+1.64%", "[+1.11, +2.18]", "5/5"],
    ["30%", "+2.62%", "[+1.45, +3.80]", "5/5 · p<0.001"],
    ["10%", "+4.19%", "[+0.72, +7.66]", "5/5 · p<0.004"],
    ["5%", "+1.85%", "[−0.22, +3.42]", "5/5"],
    ["1%", "+8.93%", "[+6.59, +10.95]", "5/5"],
  ];
  return (
    <SlideChrome secn="4‑3." title="RQ2(2) — KM20 Stratified: spatial allocation 효과" page="14">
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 30 }}>
        <figure style={{ margin: 0, border: `1px solid ${LINE}`, padding: 8 }}>
          <img src="assets/figures/phase6_box.png" alt="phase6 box" style={{ width: "100%", display: "block" }} />
          <figcaption style={{ fontSize: 10.5, color: FG3, marginTop: 6 }}>
            Phase 6 — BERNOULLI vs STRATIFIED (KM20), 100 query
          </figcaption>
        </figure>
        <div>
          <Eyebrow mb={10}>BERNOULLI 대비 KM20 효과</Eyebrow>
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13, fontFamily: "var(--font-num)", fontFeatureSettings: '"tnum" 1' }}>
            <thead>
              <tr style={{ borderBottom: `2px solid ${INK}` }}>
                {["selectivity", "5‑seed 평균", "95% CI", "유의 seed"].map(h => (
                  <th key={h} style={{ padding: "8px 10px", textAlign: "left", color: FG2, fontFamily: "var(--font-sans)" }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {rows.map(r => (
                <tr key={r[0]} style={{ borderBottom: `1px solid ${LINE}` }}>
                  <td style={{ padding: "8px 10px" }}>{r[0]}</td>
                  <td style={{ padding: "8px 10px", color: RED, fontWeight: 700 }}>{r[1]}</td>
                  <td style={{ padding: "8px 10px", fontFamily: "var(--font-mono)", fontSize: 12, color: FG2 }}>{r[2]}</td>
                  <td style={{ padding: "8px 10px", color: FG3, fontFamily: "var(--font-sans)" }}>{r[3]}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      <Quote mt={20}>
        KM20 은 <b>vector‑space skew</b> 를 sample allocation 에 반영하는 첫 번째{" "}
        <b style={{ color: RED }}>positive result</b> 다.
      </Quote>
    </SlideChrome>
  );
}

// ─── 15. RQ2(3) Two-Level decomposition ─────────────────────
function TwoLevel() {
  return (
    <SlideChrome secn="4‑4." title="RQ2(3) — Two‑Level Decomposition: 공간 효과 분리 검증" page="15">
      <div style={{ display: "grid", gridTemplateColumns: "1.4fr 1fr", gap: 28 }}>
        <figure style={{ margin: 0, border: `1px solid ${LINE}`, padding: 8 }}>
          <img src="assets/figures/figure_9_two_level_decomposition.png" alt="two-level" style={{ width: "100%", display: "block" }} />
          <figcaption style={{ fontSize: 10.5, color: FG3, marginTop: 6 }}>
            Fig 9 — L1 (RANDOM20 비례 배분) + L2 (KM20 공간 인식) 분해, BERNOULLI 대비 %
          </figcaption>
        </figure>
        <div>
          <Eyebrow mb={10}>설계 — 공간 인식의 인과 분리</Eyebrow>
          <ul style={{ margin: 0, padding: 0, listStyle: "none", display: "flex", flexDirection: "column", gap: 8, fontSize: 13, lineHeight: 1.55 }}>
            <li><b>L1 (RANDOM20)</b> — 동일한 20‑strata, 무작위 파티션, 비례 배분</li>
            <li><b>L2 (KM20 − RANDOM20)</b> — k‑means 공간 클러스터의 추가 이득</li>
          </ul>
          <Eyebrow mb={10}>Findings</Eyebrow>
          <ul style={{ margin: 0, padding: 0, listStyle: "none", display: "flex", flexDirection: "column", gap: 10, fontSize: 13, lineHeight: 1.55 }}>
            <li><span style={{ color: RED, fontWeight: 700, marginRight: 6 }}>①</span> DEEP s=0.5 ~ 0.05: <b>L2 ≫ L1</b> — 이득의 주축은 공간 인식</li>
            <li><span style={{ color: RED, fontWeight: 700, marginRight: 6 }}>②</span> SIFT s=0.5: 이미 <b>L2 = +2.06%</b> 으로 발현</li>
            <li><span style={{ color: RED, fontWeight: 700, marginRight: 6 }}>③</span> DEEP s=0.01: <b>L1 −10.67 / L2 +19.6</b> — 극단 영역에서 분해 명확</li>
          </ul>
          <Quote mt={16}>
            공간 인식 (L2) 이 이득의 주된 원인이며, 단순한 stratification 만으로는 KM20 효과를 설명할 수 없다.
          </Quote>
        </div>
      </div>
    </SlideChrome>
  );
}

// ─── 16. External validity ────────────────────────────────────
function External() {
  const stats = [
    ["DEEP 1M (96d)", "+1.64%", "[+1.11, +2.18]", "CV 0.234"],
    ["DEEP 8M (96d)", "+1.76%", "[+0.65, +2.86]", "8× scale"],
    ["SIFT 1.5M (128d)", "+3.07%", "[+2.66, +3.48]", "CV 0.394"],
  ];
  return (
    <SlideChrome secn="4‑5." title="External Validity — 3 데이터셋 교차 검증, s=0.500" page="16">
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 20, marginBottom: 16 }}>
        {stats.map(([n, v, ci, m]) => (
          <div key={n} style={{ border: `1px solid ${LINE}`, padding: "16px 20px" }}>
            <div style={{ fontSize: 12, fontWeight: 700, color: FG2 }}>{n}</div>
            <div
              style={{
                fontFamily: "var(--font-num)",
                fontSize: 44,
                fontWeight: 700,
                color: RED,
                lineHeight: 1,
                marginTop: 6,
                fontFeatureSettings: '"tnum" 1',
                letterSpacing: "-0.02em",
              }}
            >
              {v}
            </div>
            <div style={{ fontFamily: "var(--font-mono)", fontSize: 11.5, color: FG3, marginTop: 6 }}>CI {ci}</div>
            <div style={{ fontSize: 11, color: FG3, marginTop: 2 }}>{m}</div>
          </div>
        ))}
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "1.4fr 1fr", gap: 28, alignItems: "start", flex: 1, minHeight: 0 }}>
        <figure style={{ margin: 0, border: `1px solid ${LINE}`, padding: 6, display: "flex", flexDirection: "column", minHeight: 0 }}>
          <img src="assets/figures/cross_dataset_bar.png" alt="cross dataset" style={{ width: "100%", maxHeight: 220, objectFit: "contain", display: "block" }} />
          <figcaption style={{ fontSize: 10.5, color: FG3, marginTop: 4 }}>Fig 8 — KM20 효과의 외적 타당성</figcaption>
        </figure>
        <ul style={{ margin: 0, padding: 0, listStyle: "none", display: "flex", flexDirection: "column", gap: 10, fontSize: 13, lineHeight: 1.55 }}>
          <li><span style={{ color: RED, fontWeight: 700, marginRight: 6 }}>①</span> DEEP 1M ↔ 8M : CI 겹침 (CONSISTENT)</li>
          <li><span style={{ color: RED, fontWeight: 700, marginRight: 6 }}>②</span> SIFT: DEEP 보다 큰 개선폭 → 더 skewed 한 데이터에서 KM20 효과 ↑</li>
          <li><span style={{ color: RED, fontWeight: 700, marginRight: 6 }}>③</span> CV 가 1.68× 늘 때 효과는 ~2× 증가</li>
        </ul>
      </div>
    </SlideChrome>
  );
}

// ─── 17. RQ3 plan ─────────────────────────────────────────────
function RQ3() {
  const tracks = [
    ["A", "Offline Pilot", "사전 KDE / cluster size 통계 → strata 별 sample 비율 사전 산출", "Recovery rate, query‑independent"],
    ["B", "Online / Weight‑based", "Distance‑Shell, KDE‑pilot — query 별 weight 부여", "query‑adaptive, runtime overhead"],
    ["C", "Sensitivity", "K = 10 / 20 / 30 / 50, sample_size 변동", "robustness 검증"],
  ];
  return (
    <SlideChrome secn="4‑6." title="RQ3 — Skew‑Aware Allocation (예정)" page="17">
      <div style={{ fontSize: 14, color: FG2, marginBottom: 20, maxWidth: 980, lineHeight: 1.55 }}>
        KM20 은 <b>균등 비례 배분</b> 을 가정한다. RQ3 는 query 별로 <b>strata 가중치</b> 를 학습/추정해 추가 이득을 얻을 수 있는가를 검증한다.
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 0 }}>
        {tracks.map((r, i) => (
          <div
            key={i}
            style={{
              display: "grid",
              gridTemplateColumns: "60px 200px 1fr 220px",
              columnGap: 28,
              padding: "20px 0",
              borderTop: i === 0 ? `2px solid ${INK}` : `1px solid ${LINE}`,
              borderBottom: i === tracks.length - 1 ? `2px solid ${INK}` : "none",
              alignItems: "baseline",
            }}
          >
            <div style={{ fontFamily: "var(--font-num)", fontSize: 28, fontWeight: 700, color: RED }}>{r[0]}</div>
            <div style={{ fontSize: 18, fontWeight: 700, color: INK }}>{r[1]}</div>
            <div style={{ fontSize: 13.5, color: FG2, lineHeight: 1.55 }}>{r[2]}</div>
            <div style={{ fontFamily: "var(--font-mono)", fontSize: 12, color: FG3 }}>{r[3]}</div>
          </div>
        ))}
      </div>
      <Quote mt={20}>
        검증 가설 — query‑adaptive weight 가 KM20 baseline 대비 추가 ≥1% 개선 (5‑seed 95% CI).
      </Quote>
    </SlideChrome>
  );
}

// ─── 19. Roadmap ──────────────────────────────────────────────
function Roadmap() {
  const past = [
    ["W1", "✓", "4/4–4/11", "환경 인수인계 · build · Exqutor source / dataset 인계"],
    ["W2", "✓", "4/12–4/19", "RQ1 구조분석 + RQ2 본 측정 · SYSTEM→BERN, BERN→KM20"],
    ["W3", "✓", "4/20–4/26", "외적 타당성 (DEEP 8M / SIFT 1.5M) + 5‑seed 95% CI"],
    ["W4", "▶", "4/27–4/30", "중간 산출물 정리 · 보고서 · 발표"],
  ];
  const future = [
    ["W5", "5/1–5/7", "RQ2 보강 + RQ3 Offline Pilot — Low‑selectivity 반복"],
    ["W6", "5/8–5/14", "RQ3 Offline 5‑seed — 1~2 방법 × 3 데이터셋 — Recovery Rate"],
    ["W7", "5/15–5/21", "RQ3 Online / Weight‑based — Distance‑Shell, KDE‑pilot 후보"],
    ["W8", "5/22–6/11", "민감도 분석 + 최종발표 (sample_size, K=10/20/30/50)"],
  ];
  return (
    <SlideChrome secn="5‑1." title="Roadmap — 진행 상황과 향후 계획" page="19">
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 32 }}>
        <div>
          <Eyebrow mb={12}>현재 진행</Eyebrow>
          {past.map((r, i) => (
            <div
              key={r[0]}
              style={{
                display: "grid",
                gridTemplateColumns: "40px 22px 110px 1fr",
                gap: 8,
                padding: "11px 0",
                borderTop: i === 0 ? `2px solid ${INK}` : `1px solid ${LINE}`,
                borderBottom: i === past.length - 1 ? `2px solid ${INK}` : "none",
              }}
            >
              <div style={{ fontFamily: "var(--font-mono)", fontSize: 13, fontWeight: 700 }}>{r[0]}</div>
              <div style={{ color: RED, fontWeight: 700 }}>{r[1]}</div>
              <div style={{ fontFamily: "var(--font-mono)", fontSize: 12, color: FG3 }}>{r[2]}</div>
              <div style={{ fontSize: 13, color: FG1 }}>{r[3]}</div>
            </div>
          ))}
        </div>
        <div>
          <Eyebrow mb={12}>향후 계획</Eyebrow>
          {future.map((r, i) => (
            <div
              key={r[0]}
              style={{
                display: "grid",
                gridTemplateColumns: "40px 110px 1fr",
                gap: 8,
                padding: "11px 0",
                borderTop: i === 0 ? `2px solid ${INK}` : `1px solid ${LINE}`,
                borderBottom: i === future.length - 1 ? `2px solid ${INK}` : "none",
              }}
            >
              <div style={{ fontFamily: "var(--font-mono)", fontSize: 13, fontWeight: 700, color: FG3 }}>{r[0]}</div>
              <div style={{ fontFamily: "var(--font-mono)", fontSize: 12, color: FG3 }}>{r[1]}</div>
              <div style={{ fontSize: 13, color: FG1 }}>{r[2]}</div>
            </div>
          ))}
        </div>
      </div>
    </SlideChrome>
  );
}

// ─── 20. Risk / Limitations ───────────────────────────────────
function Risk() {
  const items = [
    ["#1", "Low‑selectivity 분산", "s≤0.01 에서 true cardinality 가 작아 Q‑error 변동이 크고 95% CI 가 0 을 포함.", "더 많은 query 표본 + bootstrap CI"],
    ["#2", "K‑means 사전 비용", "20‑strata 학습 비용은 dataset 단위 1회 이지만 high‑dim 에서 비례 증가.", "MiniBatchKMeans · index 재사용"],
    ["#3", "외적 타당성 표본 수", "현재 3 데이터셋. 더 다양한 dim / scale 에 대한 일반화 검증이 추가로 필요.", "GIST 1M · ANN‑Benchmarks 일부 추가 예정"],
    ["#4", "Single‑table 가정", "Hook 완화는 단일 테이블 vector range 에 한정. multi‑join 은 Exqutor ECQO 경로 의존.", "Out of scope (논문 분기 일치)"],
  ];
  return (
    <SlideChrome secn="5‑2." title="Risk &amp; Limitations — 알려진 제한과 대응" page="20">
      <div style={{ display: "flex", flexDirection: "column", gap: 0 }}>
        {items.map((r, i) => (
          <div
            key={r[0]}
            style={{
              display: "grid",
              gridTemplateColumns: "60px 220px 1fr 240px",
              columnGap: 24,
              padding: "16px 0",
              borderTop: i === 0 ? `2px solid ${INK}` : `1px solid ${LINE}`,
              borderBottom: i === items.length - 1 ? `2px solid ${INK}` : "none",
              alignItems: "baseline",
            }}
          >
            <div style={{ fontFamily: "var(--font-mono)", fontSize: 13, color: RED, fontWeight: 700 }}>{r[0]}</div>
            <div style={{ fontSize: 16, fontWeight: 700, color: INK }}>{r[1]}</div>
            <div style={{ fontSize: 13, color: FG2, lineHeight: 1.55 }}>{r[2]}</div>
            <div style={{ fontFamily: "var(--font-mono)", fontSize: 12, color: FG3, lineHeight: 1.5 }}>→ {r[3]}</div>
          </div>
        ))}
      </div>
    </SlideChrome>
  );
}

// ─── 21. References ───────────────────────────────────────────
function References() {
  const refs = [
    ["[1]", "Exqutor: An Efficient Query Optimization Framework for Vector‑Augmented Analytical Queries", "BDAI Research, 2025", "arXiv:2512.09695v2"],
    ["[2]", "pgvector — Open‑source vector similarity search for Postgres", "—", "github.com/pgvector"],
    ["[3]", "VBASE: Unifying Online Vector Similarity Search and Relational Queries", "OSDI ’23", "Microsoft Research"],
    ["[4]", "DuckDB: an Embeddable Analytical Database", "SIGMOD ’19", "duckdb.org"],
    ["[5]", "Horvitz‑Thompson estimator for stratified sampling", "JASA, 1952", "—"],
    ["[6]", "DEEP1B / SIFT1M benchmarks for ANN", "—", "research.yandex.com / corpus‑texmex.irisa.fr"],
  ];
  return (
    <SlideChrome secn="5‑3." title="References — 본 연구가 인용한 문헌" page="21">
      <div style={{ display: "flex", flexDirection: "column", gap: 0 }}>
        {refs.map((r, i) => (
          <div
            key={r[0]}
            style={{
              display: "grid",
              gridTemplateColumns: "44px 1fr 200px 200px",
              columnGap: 20,
              padding: "14px 0",
              borderTop: i === 0 ? `2px solid ${INK}` : `1px solid ${LINE}`,
              borderBottom: i === refs.length - 1 ? `2px solid ${INK}` : "none",
              alignItems: "baseline",
            }}
          >
            <div style={{ fontFamily: "var(--font-mono)", fontSize: 12, color: RED, fontWeight: 700 }}>{r[0]}</div>
            <div style={{ fontSize: 14, color: INK, lineHeight: 1.45 }}>{r[1]}</div>
            <div style={{ fontSize: 12, color: FG2 }}>{r[2]}</div>
            <div style={{ fontFamily: "var(--font-mono)", fontSize: 11.5, color: FG3 }}>{r[3]}</div>
          </div>
        ))}
      </div>
    </SlideChrome>
  );
}

// ─── 22. Closer ───────────────────────────────────────────────
function Closer() {
  return (
    <>
      <div style={{ width: 158, height: 2, background: RED, marginBottom: 6 }} />
      <div
        style={{
          fontSize: TYPE_SCALE.eyebrow,
          fontWeight: 700,
          letterSpacing: "0.16em",
          textTransform: "uppercase",
          color: RED,
        }}
      >
        CAPSTONE 2026‑1 / MIDTERM PRESENTATION / 연세대학교
      </div>
      <div style={{ flex: 1, display: "flex", flexDirection: "column", justifyContent: "center", alignItems: "flex-start" }}>
        <div style={{ fontSize: 96, fontWeight: 800, color: INK, letterSpacing: "-0.03em", lineHeight: 1 }}>감사합니다.</div>
        <div style={{ fontSize: 48, fontWeight: 700, color: RED, marginTop: 22, letterSpacing: "-0.02em" }}>Q &amp; A</div>
        <div style={{ marginTop: 56, paddingTop: 18, borderTop: `2px solid ${INK}`, minWidth: 480 }}>
          <div style={{ fontSize: 24, fontWeight: 800, letterSpacing: "-0.01em" }}>속도는벡터</div>
          <div style={{ fontSize: 14, color: FG2, marginTop: 6 }}>박세은 (팀장) · 강재현 · 조현빈 · 이동욱</div>
          <div style={{ fontSize: 12, color: FG3, marginTop: 4, fontFamily: "var(--font-mono)" }}>
            arXiv:2512.09695v2 · BDAI‑Research / Exqutor
          </div>
        </div>
      </div>
      <div
        style={{
          position: "absolute",
          left: SPACING.paddingX,
          right: SPACING.paddingX,
          bottom: 18,
          display: "flex",
          justifyContent: "space-between",
          fontFamily: "var(--font-mono)",
          fontSize: 11,
          color: FG3,
          paddingTop: 8,
          borderTop: `1px solid ${LINE}`,
        }}
      >
        <span style={{ whiteSpace: "nowrap" }}>속도는벡터 · 박세은 · 강재현 · 조현빈 · 이동욱</span>
        <span style={{ whiteSpace: "nowrap" }}>22 / 22</span>
      </div>
    </>
  );
}

// ─── Expose ───────────────────────────────────────────────────
Object.assign(window, {
  Cover, TOC, SectionDivider,
  Problem, Background, VectorC,
  Approach, Contributions,
  RQ1Heatmap, RQ2Table, RQ2KM20, TwoLevel, External, RQ3,
  Roadmap, Risk, References, Closer,
});
