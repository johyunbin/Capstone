/* global React, SlideShell, Scribble, Lorem, Box, FakeChart, FakeTable, Eyebrow, StickyNote, Squiggle, W, HAND */

// ═══════════════════════════════════════════════════════════════
// CODE-DIFF (vector.c) variations — 5
// ═══════════════════════════════════════════════════════════════

function Code_A_DiffAndNotes() {
  return (
    <SlideShell secn="2‑2." title="Adaptive Sampling 의 한계 — vector.c" page="5 / 12">
      <div style={{ display:'grid', gridTemplateColumns:'1.05fr 1fr', gap: 28 }}>
        <div style={{ background:'#0A0A0A', padding:'18px 20px', fontFamily:'JetBrains Mono, monospace', fontSize: 12.5, lineHeight: 1.7, color:'#F5F5F4' }}>
          <div style={{ color:'#737373', marginBottom: 8 }}>// Pivot A — line 243</div>
          <div style={{ color:'#FCA5A5' }}>- if (table_count &gt; 2)</div>
          <div style={{ color:'#86EFAC' }}>+ if (table_count &gt;= 1)</div>
          <div style={{ height: 14 }}/>
          <div style={{ color:'#737373', marginBottom: 8 }}>// Pivot B — line 889</div>
          <div style={{ color:'#FCA5A5' }}>- TABLESAMPLE SYSTEM(%f)</div>
          <div style={{ color:'#86EFAC' }}>+ TABLESAMPLE BERNOULLI(%f)</div>
          <div style={{ height: 14 }}/>
          <div style={{ color:'#737373', marginBottom: 8 }}>// Pivot C</div>
          <div style={{ color:'#86EFAC' }}>+ KM20 stratified branch (+228)</div>
        </div>
        <div style={{ display:'flex', flexDirection:'column', gap: 12 }}>
          {[['#1','Hook trigger 누락'],['#2','Gate relaxation 부작용'],['#3','Block‑level bias']].map(([n,t],i)=>(
            <div key={i} style={{ borderLeft: `3px solid ${W.red}`, paddingLeft: 12 }}>
              <div style={{ fontFamily:'JetBrains Mono', fontSize: 11, color: W.red, fontWeight: 700 }}>{n}</div>
              <div style={{ fontSize: 14, fontWeight: 700, marginTop: 2 }}>{t}</div>
              <Scribble w="90%" h={4} c={W.lineLight}/>
              <Scribble w="70%" h={4} mb={0} c={W.lineLight}/>
            </div>
          ))}
        </div>
      </div>
      <StickyNote bottom={80} right={70} rotate={2} w={150}>diff + 3 메모</StickyNote>
    </SlideShell>
  );
}

function Code_B_FullDiff() {
  return (
    <SlideShell secn="2‑2." title="vector.c — 핵심 변경 요약" page="5 / 12">
      <div style={{ background:'#0A0A0A', padding: 22, fontFamily:'JetBrains Mono, monospace', fontSize: 14, lineHeight: 1.7, color:'#F5F5F4' }}>
        <div style={{ color:'#737373' }}>// Pivot A — Hook trigger (line 243)</div>
        <div style={{ color:'#FCA5A5' }}>- if (table_count &gt; 2)</div>
        <div style={{ color:'#86EFAC' }}>+ if (table_count &gt;= 1)</div>
        <div style={{ height: 18 }}/>
        <div style={{ color:'#737373' }}>// Pivot B — Sampling method (line 889)</div>
        <div style={{ color:'#FCA5A5' }}>- TABLESAMPLE SYSTEM(%f)</div>
        <div style={{ color:'#86EFAC' }}>+ TABLESAMPLE BERNOULLI(%f)</div>
        <div style={{ height: 18 }}/>
        <div style={{ color:'#737373' }}>// Pivot C — Stratified branch (+228)</div>
        <div style={{ color:'#86EFAC' }}>+ KM20 strata read → per‑stratum BERN → HT aggregate</div>
      </div>
      <StickyNote bottom={130} right={70} rotate={-2} w={150}>diff 단독, 풀폭</StickyNote>
    </SlideShell>
  );
}

function Code_C_BeforeAfter() {
  return (
    <SlideShell secn="2‑2." title="Before / After" page="5 / 12">
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap: 24 }}>
        <div>
          <Eyebrow c={W.fg2}>BEFORE — Adaptive Sampling</Eyebrow>
          <div style={{ background: W.bg2, border: `1px dashed ${W.line}`, padding: 18, fontFamily:'JetBrains Mono', fontSize: 13, lineHeight: 1.6 }}>
            <div>table_count &gt; 2 ✓</div>
            <div>SYSTEM (block) ✓</div>
            <div style={{ color: W.fg3 }}>no stratification</div>
            <div style={{ marginTop: 14, color: W.fg3 }}>// 단일 vector table query</div>
            <div style={{ color: W.red, fontWeight: 700 }}>// → AS 미진입, 1/3 fallback</div>
          </div>
        </div>
        <div>
          <Eyebrow>AFTER — 본 연구</Eyebrow>
          <div style={{ background:'#FEE2E2', border: `1.5px solid ${W.red}`, padding: 18, fontFamily:'JetBrains Mono', fontSize: 13, lineHeight: 1.6 }}>
            <div>table_count &gt;= 1 ✓</div>
            <div>BERNOULLI (row) ✓</div>
            <div style={{ fontWeight: 700 }}>+ KM20 stratified ✓</div>
            <div style={{ marginTop: 14, color: W.fg3 }}>// estimation‑only path</div>
            <div style={{ color: W.red, fontWeight: 700 }}>// → skew‑aware allocation</div>
          </div>
        </div>
      </div>
      <div style={{ marginTop: 24, padding:'12px 18px', borderLeft: `3px solid ${W.red}`, background: W.bg2, fontSize: 14 }}>
        ★ 실행 plan 을 바꾸지 않는 <Squiggle>estimation‑only sampling 경로</Squiggle> 가 필요하다.
      </div>
      <StickyNote top={130} right={70} rotate={3} w={140}>좌우 대비 패널</StickyNote>
    </SlideShell>
  );
}

function Code_D_Annotated() {
  return (
    <SlideShell secn="2‑2." title="vector.c (line 243) — 주석된 diff" page="5 / 12">
      <div style={{ position:'relative' }}>
        <div style={{ background:'#0A0A0A', padding: 22, fontFamily:'JetBrains Mono', fontSize: 13, lineHeight: 1.8, color:'#F5F5F4', marginRight: 280 }}>
          <div style={{ color:'#FCA5A5' }}>- if (table_count &gt; 2) <span style={{ color:'#FBBF24' }}>// ←ⓐ</span></div>
          <div style={{ color:'#86EFAC' }}>+ if (table_count &gt;= 1)</div>
          <div style={{ color:'#FCA5A5', marginTop: 18 }}>- TABLESAMPLE SYSTEM(%f) <span style={{ color:'#FBBF24' }}>// ←ⓑ</span></div>
          <div style={{ color:'#86EFAC' }}>+ TABLESAMPLE BERNOULLI(%f)</div>
          <div style={{ color:'#86EFAC', marginTop: 18 }}>+ KM20 strata branch <span style={{ color:'#FBBF24' }}>// ←ⓒ</span></div>
        </div>
        <div style={{ position:'absolute', right: 0, top: 0, width: 260 }}>
          {[['ⓐ','hook 활성화 조건 완화'],['ⓑ','row‑level 균일성 보장'],['ⓒ','spatial allocation 추가']].map(([k,t],i)=>(
            <div key={i} style={{ background:'#FEF9C3', border: '1px solid #FACC15', padding:'8px 12px', fontSize: 12, marginBottom: 8, transform: `rotate(${i%2?1:-1}deg)`, fontFamily: HAND }}>
              <b style={{ color: W.red }}>{k}</b> {t}
            </div>
          ))}
        </div>
      </div>
      <StickyNote bottom={100} right={70} rotate={3} w={150}>코드 + 인라인 주석 핀</StickyNote>
    </SlideShell>
  );
}

function Code_E_TextHeavy() {
  return (
    <SlideShell secn="2‑2." title="3 가지 변경 — 의사결정 근거" page="5 / 12">
      <div style={{ display:'flex', flexDirection:'column', gap: 14 }}>
        {[
          ['#1 Hook trigger', 'table_count>2 → ≥1', '단일 vector table query 도 AS 진입 → fallback 차단'],
          ['#2 Sampling method', 'SYSTEM → BERNOULLI', 'block bias 제거, row‑level uniformity 확보'],
          ['#3 Stratified branch', '(none) → KM20 strata', 'spatial skew 를 sample allocation 에 반영'],
        ].map(([t,c,d],i)=>(
          <div key={i} style={{ display:'grid', gridTemplateColumns:'200px 240px 1fr', gap: 18, padding:'14px 0', borderTop: i===0?`2px solid ${W.ink}`:`1px dashed ${W.lineLight}` }}>
            <div style={{ fontSize: 16, fontWeight: 700, color: W.red }}>{t}</div>
            <div style={{ fontFamily:'JetBrains Mono', fontSize: 12, color: W.fg2, alignSelf:'center' }}>{c}</div>
            <div style={{ fontSize: 13, color: W.ink, alignSelf:'center' }}>{d}</div>
          </div>
        ))}
      </div>
      <StickyNote bottom={100} right={70} rotate={-2} w={150}>표로 결정 근거 정리</StickyNote>
    </SlideShell>
  );
}

window.CodeVariations = [Code_A_DiffAndNotes, Code_B_FullDiff, Code_C_BeforeAfter, Code_D_Annotated, Code_E_TextHeavy];

// ═══════════════════════════════════════════════════════════════
// APPROACH variations — 5
// ═══════════════════════════════════════════════════════════════

function Approach_A_TwoCol() {
  return (
    <SlideShell secn="3." title="Skew‑Aware Stratified Sampling" page="6 / 12">
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap: 40 }}>
        <div>
          <Eyebrow c={W.fg3}>기존</Eyebrow>
          <div style={{ fontSize: 22, fontWeight: 700, color: W.fg2 }}>Uniform Adaptive Sampling</div>
          <div style={{ height: 1, background: W.line, margin:'18px 0' }}/>
          <Eyebrow>제안</Eyebrow>
          <div style={{ fontSize: 26, fontWeight: 700 }}>Skew‑Aware Stratified Sampling</div>
          <div style={{ fontFamily:'JetBrains Mono', fontSize: 14, color: W.red, marginTop: 10, fontWeight: 700 }}>SYSTEM → BERN → KM20</div>
        </div>
        <div>
          <Eyebrow>핵심 기여</Eyebrow>
          {['Target — 단일 테이블 vector range','Decomposition — block bias / spatial skew 분리','Validation — RANDOM20 / Two‑Level'].map((t,i)=>(
            <div key={i} style={{ padding:'10px 0', borderBottom: `1px dashed ${W.lineLight}`, fontSize: 14 }}>
              <span style={{ color: W.red, fontWeight: 700 }}>{['①','②','③'][i]}</span> {t}
            </div>
          ))}
        </div>
      </div>
      <div style={{ marginTop: 28, padding:'14px 18px', background: W.bg2, borderLeft: `3px solid ${W.red}`, fontSize: 14 }}>
        ✦ <Squiggle>block bias 제거 후 sample allocation 재설계</Squiggle>
      </div>
      <StickyNote bottom={70} right={70} rotate={2} w={150}>대비 + 기여 + 핵심</StickyNote>
    </SlideShell>
  );
}

function Approach_B_Pipeline() {
  return (
    <SlideShell secn="3." title="제안 파이프라인" page="6 / 12">
      <div style={{ marginTop: 30, display:'flex', alignItems:'center', justifyContent:'space-between' }}>
        {['SYSTEM','BERNOULLI','KM20'].map((t,i)=>(
          <React.Fragment key={t}>
            <div style={{
              width: 180, height: 180, borderRadius:'50%',
              border: `2px ${i===2?'solid':'dashed'} ${i===2?W.red:W.fg3}`,
              display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center',
              fontFamily:'JetBrains Mono', background: i===2?'#FEE2E2':W.bg
            }}>
              <div style={{ fontSize: 11, color: W.fg3 }}>STEP {i+1}</div>
              <div style={{ fontSize: 22, fontWeight: 700, color: i===2?W.red:W.ink, marginTop: 4 }}>{t}</div>
              <div style={{ fontSize: 11, color: W.fg2, marginTop: 8, textAlign:'center' }}>
                {['block 단위','row 단위','strata 단위'][i]}
              </div>
            </div>
            {i<2 && <div style={{ flex:1, height: 2, borderTop: `2px dashed ${W.fg3}`, margin:'0 12px', position:'relative' }}>
              <div style={{ position:'absolute', top: -22, left:'40%', fontSize: 12, color: W.red, fontWeight: 700 }}>
                {i===0?'block bias 제거':'spatial allocation'}
              </div>
            </div>}
          </React.Fragment>
        ))}
      </div>
      <div style={{ marginTop: 30, display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap: 14 }}>
        {['추정 단순', '+9.6% (s=0.5)', '+1.64 ~ +3.07%'].map((v,i)=>(
          <div key={i} style={{ padding: 12, border: `1px dashed ${W.line}`, textAlign:'center' }}>
            <div style={{ fontSize: 18, fontWeight: 700, color: i===2?W.red:W.fg2, fontFamily:'Inter, sans-serif' }}>{v}</div>
          </div>
        ))}
      </div>
      <StickyNote bottom={130} right={70} rotate={-2} w={150}>3단계 진화 시각화</StickyNote>
    </SlideShell>
  );
}

function Approach_C_Equation() {
  return (
    <SlideShell secn="3." title="제안 — 공식적 구조" page="6 / 12">
      <div style={{ display:'flex', flexDirection:'column', gap: 30, paddingTop: 24 }}>
        <div style={{ background: W.bg2, padding: 30, border:`1px dashed ${W.line}`, fontFamily:'JetBrains Mono', fontSize: 24, color: W.ink, textAlign:'center' }}>
          N̂<sub style={{ fontSize: 14 }}>KM20</sub> = Σ<sub style={{ fontSize: 14 }}>k</sub> (N<sub style={{ fontSize: 14 }}>k</sub> / n<sub style={{ fontSize: 14 }}>k</sub>) · Σ <span style={{ color: W.red }}>𝟙</span>(x<sub style={{ fontSize: 14 }}>i</sub> ∈ R)
        </div>
        <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap: 16 }}>
          {[
            ['k','vector‑space cluster (K=20)'],
            ['N_k / n_k','HT inflation factor'],
            ['𝟙(x ∈ R)','range membership']
          ].map(([s,d],i)=>(
            <div key={i}>
              <div style={{ fontFamily:'JetBrains Mono', fontSize: 14, color: W.red, fontWeight: 700 }}>{s}</div>
              <Scribble w="80%" h={5} mb={0} c={W.lineLight}/>
              <div style={{ fontSize: 12, color: W.fg2, marginTop: 4 }}>{d}</div>
            </div>
          ))}
        </div>
      </div>
      <StickyNote bottom={130} right={70} rotate={3} w={140}>수식 중심</StickyNote>
    </SlideShell>
  );
}

function Approach_D_Visual() {
  return (
    <SlideShell secn="3." title="Skew‑Aware 의 직관" page="6 / 12">
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap: 32 }}>
        <div>
          <Eyebrow c={W.fg3}>Uniform — 전체에 동일 비율</Eyebrow>
          <div style={{ position:'relative', width:'100%', height: 220, border:`1.5px dashed ${W.line}`, marginTop: 8 }}>
            {Array.from({length: 40}).map((_,i)=>(
              <div key={i} style={{ position:'absolute', left:`${(i*53)%92}%`, top:`${(i*37)%88}%`, width: 5, height: 5, borderRadius:'50%', background: i<6?W.red:W.fg3, opacity: i<6?1:0.4 }}/>
            ))}
          </div>
          <div style={{ fontSize: 11, color: W.fg3, marginTop: 6, fontFamily:'JetBrains Mono' }}>밀도 차이 무시 → 대표성↓</div>
        </div>
        <div>
          <Eyebrow>KM20 — strata 별 할당</Eyebrow>
          <div style={{ position:'relative', width:'100%', height: 220, border:`1.5px solid ${W.red}`, marginTop: 8, background:'#FEE2E2' }}>
            {[[15,20,30],[55,30,28],[15,65,18],[60,70,24],[85,40,16]].map(([x,y,r],i)=>(
              <div key={i} style={{ position:'absolute', left:`${x}%`, top:`${y}%`, width:r, height:r, borderRadius:'50%', border:`1.2px solid ${W.red}`, transform:'translate(-50%,-50%)' }}/>
            ))}
            {Array.from({length: 30}).map((_,i)=>(
              <div key={i} style={{ position:'absolute', left:`${(i*53)%92}%`, top:`${(i*37)%88}%`, width: 4, height: 4, borderRadius:'50%', background: W.ink, opacity: 0.7 }}/>
            ))}
          </div>
          <div style={{ fontSize: 11, color: W.red, marginTop: 6, fontFamily:'JetBrains Mono', fontWeight: 700 }}>cluster 별 sample → 대표성↑</div>
        </div>
      </div>
      <div style={{ marginTop: 22, padding:'10px 14px', background: W.bg2, borderLeft: `3px solid ${W.red}`, fontSize: 13 }}>
        ✦ K=20 cluster 위에 per‑stratum BERNOULLI → Horvitz‑Thompson 합산
      </div>
      <StickyNote top={130} right={70} rotate={-2} w={150}>도식 비교 (점·원)</StickyNote>
    </SlideShell>
  );
}

function Approach_E_Stack() {
  return (
    <SlideShell secn="3." title="제안 — 스택" page="6 / 12">
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1.2fr', gap: 28, alignItems:'start' }}>
        <div>
          {['Aggregation: Horvitz‑Thompson','Sampling: BERNOULLI per stratum','Stratification: KM20 (k=20)','Index: KMeans (offline)','Source: vector embeddings'].map((t,i)=>(
            <div key={i} style={{ padding:'14px 18px', border: `1.5px ${i===2?'solid':'dashed'} ${i===2?W.red:W.line}`, marginBottom: 6, fontSize: 14, fontWeight: i===2?700:400, color: i===2?W.red:W.ink, background: i===2?'#FEE2E2':W.bg, fontFamily: i<3?'JetBrains Mono':HAND }}>
              {t}
            </div>
          ))}
        </div>
        <div>
          <Eyebrow>설계 결정</Eyebrow>
          <Lorem lines={4} c={W.lineLight}/>
          <div style={{ height: 14 }}/>
          <Eyebrow>대안 (기각)</Eyebrow>
          <Lorem lines={3} c={W.lineLight} last="40%"/>
          <div style={{ marginTop: 18, padding: 14, borderLeft: `3px solid ${W.red}`, background: W.bg2, fontSize: 13 }}>
            <Squiggle>K=20</Squiggle> 은 sensitivity sweep 으로 결정 (W8 예정)
          </div>
        </div>
      </div>
      <StickyNote bottom={130} right={70} rotate={2} w={140}>스택 다이어그램</StickyNote>
    </SlideShell>
  );
}

window.ApproachVariations = [Approach_A_TwoCol, Approach_B_Pipeline, Approach_C_Equation, Approach_D_Visual, Approach_E_Stack];

// ═══════════════════════════════════════════════════════════════
// ROADMAP variations — 5
// ═══════════════════════════════════════════════════════════════

const PAST = [
  ['W1','✓','4/4–4/11','환경 인수인계 · build · server'],
  ['W2','✓','4/12–4/19','RQ1 + RQ2 본 측정'],
  ['W3','✓','4/20–4/26','외적 타당성 · 5‑seed CI'],
  ['W4','▶','4/27–4/30','중간발표 정리'],
];
const FUTURE = [
  ['W5','4/29–5/6','RQ2 보강 + RQ3 Offline Pilot'],
  ['W6','5/7–5/13','RQ3 Offline 5‑seed'],
  ['W7','5/14–5/20','RQ3 Online / Weight‑based'],
  ['W8','5/21–5/27','민감도 분석 + 최종발표'],
];

function Roadmap_A_TwoCol() {
  return (
    <SlideShell secn="5." title="진행 현황 & 향후 계획" page="11 / 12">
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap: 32 }}>
        <div>
          <Eyebrow>Current progress</Eyebrow>
          {PAST.map((r,i)=>(
            <div key={i} style={{ display:'grid', gridTemplateColumns:'30px 22px 100px 1fr', gap: 8, padding:'10px 0', borderBottom: `1px dashed ${W.lineLight}` }}>
              <div style={{ fontFamily:'JetBrains Mono', fontSize: 12, fontWeight: 700 }}>{r[0]}</div>
              <div style={{ color: W.red, fontWeight: 700 }}>{r[1]}</div>
              <div style={{ fontFamily:'JetBrains Mono', fontSize: 11, color: W.fg3 }}>{r[2]}</div>
              <div style={{ fontSize: 12 }}>{r[3]}</div>
            </div>
          ))}
        </div>
        <div>
          <Eyebrow>향후 계획</Eyebrow>
          {FUTURE.map((r,i)=>(
            <div key={i} style={{ display:'grid', gridTemplateColumns:'30px 100px 1fr', gap: 8, padding:'10px 0', borderBottom: `1px dashed ${W.lineLight}` }}>
              <div style={{ fontFamily:'JetBrains Mono', fontSize: 12, fontWeight: 700, color: W.fg3 }}>{r[0]}</div>
              <div style={{ fontFamily:'JetBrains Mono', fontSize: 11, color: W.fg3 }}>{r[1]}</div>
              <div style={{ fontSize: 12 }}>{r[2]}</div>
            </div>
          ))}
        </div>
      </div>
      <StickyNote bottom={70} right={70} rotate={-2} w={150}>좌 완료 / 우 계획</StickyNote>
    </SlideShell>
  );
}

function Roadmap_B_Gantt() {
  return (
    <SlideShell secn="5." title="Gantt — W1~W8" page="11 / 12">
      <div style={{ display:'grid', gridTemplateColumns:'120px repeat(8, 1fr)', gap: 2, fontSize: 11, fontFamily:'JetBrains Mono', marginTop: 16 }}>
        <div></div>
        {['W1','W2','W3','W4','W5','W6','W7','W8'].map(w=><div key={w} style={{ textAlign:'center', color: W.fg3, padding:'4px 0' }}>{w}</div>)}
        {[
          ['환경 인수',[1,1]],['RQ1 분석',[2,2]],['RQ2 측정',[2,4]],['외적 타당성',[3,3]],
          ['중간정리',[4,4]],['RQ3 pilot',[5,6]],['RQ3 online',[7,7]],['민감도/최종',[7,8]]
        ].map(([n,[s,e]],i)=>(
          <React.Fragment key={i}>
            <div style={{ padding:'6px 8px', borderTop: `1px dashed ${W.lineLight}`, fontFamily: HAND, fontSize: 12 }}>{n}</div>
            {Array.from({length: 8}).map((_,j)=>{
              const inRange = j+1 >= s && j+1 <= e;
              const past = j+1 <= 4;
              return <div key={j} style={{ borderTop: `1px dashed ${W.lineLight}`, padding: 4 }}>
                {inRange && <div style={{ height: 14, background: past?W.red:W.fg4, opacity: past?1:0.7 }}/>}
              </div>;
            })}
          </React.Fragment>
        ))}
      </div>
      <div style={{ marginTop: 18, display:'flex', gap: 18, fontSize: 11, color: W.fg3, fontFamily:'JetBrains Mono' }}>
        <span><span style={{ display:'inline-block', width: 12, height: 8, background: W.red, marginRight: 6 }}/>완료</span>
        <span><span style={{ display:'inline-block', width: 12, height: 8, background: W.fg4, marginRight: 6 }}/>예정</span>
      </div>
      <StickyNote bottom={130} right={70} rotate={2} w={150}>간트 차트</StickyNote>
    </SlideShell>
  );
}

function Roadmap_C_Timeline() {
  return (
    <SlideShell secn="5." title="Timeline" page="11 / 12">
      <svg viewBox="0 0 1100 360" style={{ width:'100%', height: 360 }}>
        <line x1="40" y1="180" x2="1060" y2="180" stroke={W.fg3} strokeWidth="1.2"/>
        <line x1="40" y1="180" x2="540" y2="180" stroke={W.red} strokeWidth="3"/>
        {Array.from({length:8}).map((_,i)=>{
          const x = 80 + i * 130;
          const past = i < 4;
          const items = [...PAST, ...FUTURE];
          const it = items[i];
          return (
            <g key={i}>
              <circle cx={x} cy="180" r="10" fill={past?W.red:W.bg} stroke={W.red} strokeWidth="1.5"/>
              <text x={x} y="184" textAnchor="middle" fontSize="10" fontWeight="700" fill={past?W.bg:W.red} fontFamily="JetBrains Mono">{it[0]}</text>
              <text x={x} y={i%2?125:240} textAnchor="middle" fontSize="13" fontWeight="700" fontFamily="Kalam">{it[i<4?3:2]}</text>
              <text x={x} y={i%2?108:258} textAnchor="middle" fontSize="10" fill={W.fg3} fontFamily="JetBrains Mono">{it[i<4?2:1]}</text>
            </g>
          );
        })}
        <text x="280" y="40" textAnchor="middle" fontSize="11" fill={W.red} fontFamily="JetBrains Mono" fontWeight="700">DONE</text>
        <text x="800" y="40" textAnchor="middle" fontSize="11" fill={W.fg3} fontFamily="JetBrains Mono" fontWeight="700">PLANNED</text>
      </svg>
      <StickyNote bottom={130} right={70} rotate={-2} w={140}>수평 타임라인</StickyNote>
    </SlideShell>
  );
}

function Roadmap_D_Status() {
  return (
    <SlideShell secn="5." title="Status — at a glance" page="11 / 12">
      <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap: 14, marginBottom: 28 }}>
        {[['4/8','주차 완료'],['100%','RQ1·RQ2'],['3','검증 데이터셋'],['+1.64~3.07%','효과 범위']].map(([v,l],i)=>(
          <div key={i} style={{ border: `1.5px dashed ${W.line}`, padding: 16 }}>
            <div style={{ fontSize: 30, fontWeight: 700, color: W.red, fontFamily:'Inter, sans-serif' }}>{v}</div>
            <div style={{ fontSize: 11, color: W.fg3, fontFamily:'JetBrains Mono', marginTop: 6 }}>{l}</div>
          </div>
        ))}
      </div>
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap: 28 }}>
        <div>
          <Eyebrow>Risk</Eyebrow>
          <Lorem lines={3} c={W.lineLight}/>
        </div>
        <div>
          <Eyebrow>Mitigation</Eyebrow>
          <Lorem lines={3} c={W.lineLight}/>
        </div>
      </div>
      <StickyNote bottom={70} right={70} rotate={3} w={150}>대시보드 형식</StickyNote>
    </SlideShell>
  );
}

function Roadmap_E_Checklist() {
  return (
    <SlideShell secn="5." title="체크리스트" page="11 / 12">
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap: 32 }}>
        <div>
          <Eyebrow>완료</Eyebrow>
          {['환경 인수인계','RQ1 구조 분석','RQ2 SYS→BERN','RQ2 KM20','외적 타당성 (DEEP/SIFT)'].map((t,i)=>(
            <div key={i} style={{ display:'flex', alignItems:'center', gap: 12, padding:'8px 0', fontSize: 14 }}>
              <span style={{ width: 18, height: 18, border: `1.5px solid ${W.red}`, color: W.red, fontWeight: 700, display:'flex', alignItems:'center', justifyContent:'center', fontFamily:'JetBrains Mono', fontSize: 12 }}>✓</span>
              <span>{t}</span>
            </div>
          ))}
        </div>
        <div>
          <Eyebrow>남은 작업</Eyebrow>
          {['RQ3 Offline pilot','RQ3 Online','Weight‑based 후보','민감도 (K, sample_size)','최종 보고서 v2'].map((t,i)=>(
            <div key={i} style={{ display:'flex', alignItems:'center', gap: 12, padding:'8px 0', fontSize: 14 }}>
              <span style={{ width: 18, height: 18, border: `1.5px dashed ${W.fg3}`, fontFamily:'JetBrains Mono', fontSize: 12 }}/>
              <span style={{ color: W.fg2 }}>{t}</span>
            </div>
          ))}
        </div>
      </div>
      <StickyNote bottom={70} right={70} rotate={-2} w={150}>체크리스트 톤</StickyNote>
    </SlideShell>
  );
}

window.RoadmapVariations = [Roadmap_A_TwoCol, Roadmap_B_Gantt, Roadmap_C_Timeline, Roadmap_D_Status, Roadmap_E_Checklist];
