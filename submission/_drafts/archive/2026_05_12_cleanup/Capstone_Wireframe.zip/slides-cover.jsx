/* global React, SlideShell, Scribble, Lorem, Box, FakeChart, FakeTable, Eyebrow, StickyNote, Squiggle, W, HAND */

// ═══════════════════════════════════════════════════════════════
// COVER variations — 5
// ═══════════════════════════════════════════════════════════════

function Cover_A_LeftAlign() {
  return (
    <SlideShell hideHeader>
      <div style={{ flex:1, display:'flex', flexDirection:'column', justifyContent:'center', paddingTop: 40 }}>
        <div style={{ fontSize: 14, color: W.fg3, marginBottom: 18 }}>속도는벡터 · 2026‑04‑30</div>
        <div style={{ fontSize: 56, fontWeight: 700, lineHeight: 1.1, letterSpacing: '-0.02em', maxWidth: 1000, marginBottom: 32, fontFamily: HAND }}>
          <Squiggle>Skew‑Aware Stratified Sampling</Squiggle> 을 이용한<br/>
          Vector Cardinality 추정 정확도 개선 연구
        </div>
        <div style={{ display:'flex', gap: 56, alignItems:'flex-end' }}>
          <div>
            <Eyebrow>팀</Eyebrow>
            <div style={{ fontSize: 24, fontWeight: 700 }}>속도는벡터</div>
            <Scribble w={260} h={6} mb={4} c={W.lineLight}/>
            <Scribble w={220} h={6} mb={0} c={W.lineLight}/>
          </div>
          <div style={{ borderLeft: `1px dashed ${W.line}`, paddingLeft: 28 }}>
            <Eyebrow>지도</Eyebrow>
            <Scribble w={200} h={6} mb={6} c={W.lineLight}/>
            <Scribble w={170} h={6} mb={0} c={W.lineLight}/>
          </div>
        </div>
      </div>
      <StickyNote top={120} right={90} rotate={3} w={170}>큰 타이틀 좌측 정렬, 메타 하단</StickyNote>
    </SlideShell>
  );
}

function Cover_B_Centered() {
  return (
    <SlideShell hideHeader>
      <div style={{ flex:1, display:'flex', flexDirection:'column', justifyContent:'center', alignItems:'center', textAlign:'center' }}>
        <div style={{ fontSize: 11, color: W.red, fontFamily:'JetBrains Mono, monospace', letterSpacing:'0.2em', marginBottom: 30 }}>MIDTERM · 2026‑04‑30</div>
        <div style={{ width: 1, height: 64, background: W.red, marginBottom: 28 }}/>
        <div style={{ fontSize: 64, fontWeight: 700, lineHeight: 1.05, letterSpacing: '-0.02em', maxWidth: 1000, marginBottom: 32 }}>
          Skew‑Aware<br/>Stratified Sampling
        </div>
        <Scribble w={500} h={6} mb={12} c={W.line}/>
        <Scribble w={380} h={6} mb={32} c={W.lineLight}/>
        <div style={{ fontSize: 18, fontWeight: 700 }}>속도는벡터</div>
        <Scribble w={300} h={6} mb={0} c={W.lineLight} />
      </div>
      <StickyNote bottom={70} left={80} rotate={-2} w={170}>중앙 정렬, 수직 룰 강조</StickyNote>
    </SlideShell>
  );
}

function Cover_C_BigNumber() {
  return (
    <SlideShell hideHeader>
      <div style={{ flex:1, display:'grid', gridTemplateColumns:'1.4fr 1fr', gap: 60, alignItems:'center' }}>
        <div>
          <Eyebrow>핵심 결과 — 5‑seed 95% CI</Eyebrow>
          <div style={{ fontSize: 220, fontWeight: 700, color: W.red, lineHeight: 0.85, letterSpacing:'-0.04em', fontFamily: 'Inter, sans-serif' }}>+3.07%</div>
          <div style={{ fontSize: 16, color: W.fg2, marginTop: 12 }}>SIFT 1.5M Q‑error 개선 (KM20)</div>
        </div>
        <div>
          <div style={{ fontSize: 32, fontWeight: 700, lineHeight: 1.15, marginBottom: 20 }}>Skew‑Aware<br/>Stratified Sampling</div>
          <Scribble w="80%" h={6} mb={6} c={W.lineLight}/>
          <Scribble w="70%" h={6} mb={6} c={W.lineLight}/>
          <Scribble w="60%" h={6} mb={20} c={W.lineLight}/>
          <div style={{ paddingTop: 20, borderTop: `2px solid ${W.ink}` }}>
            <div style={{ fontSize: 18, fontWeight: 700 }}>속도는벡터</div>
            <Scribble w={220} h={5} mb={4} c={W.lineLight}/>
          </div>
        </div>
      </div>
      <StickyNote top={70} right={80} rotate={2} w={180}>결과 우선 — 표지에서 효과 크기 노출</StickyNote>
    </SlideShell>
  );
}

function Cover_D_Editorial() {
  return (
    <SlideShell hideHeader>
      <div style={{ flex:1, display:'flex', flexDirection:'column' }}>
        <div style={{ fontSize: 11, color: W.fg3, fontFamily:'JetBrains Mono, monospace', letterSpacing: '0.16em', marginTop: 60, marginBottom: 18 }}>
          ISSUE 01 / 2026‑04‑30
        </div>
        <div style={{ fontSize: 14, color: W.red, fontWeight: 700, marginBottom: 6 }}>RESEARCH PROPOSAL</div>
        <div style={{ height: 1, background: W.ink, width:'100%', marginBottom: 22 }}/>
        <div style={{ fontSize: 72, fontWeight: 700, lineHeight: 1.0, letterSpacing: '-0.03em' }}>
          Vector Cardinality<br/>의 사각지대를<br/>다시 본다.
        </div>
        <div style={{ height: 1, background: W.ink, width:'100%', marginTop: 30, marginBottom: 16 }}/>
        <div style={{ display:'flex', justifyContent:'space-between', fontSize: 13, color: W.fg2 }}>
          <div>속도는벡터 · 박세은 외 3</div>
          <div style={{ fontFamily:'JetBrains Mono, monospace', fontSize: 11 }}>BDAI · 박광현</div>
        </div>
      </div>
      <StickyNote top={90} right={80} rotate={3} w={160}>잡지 표지 톤 / 큰 타입</StickyNote>
    </SlideShell>
  );
}

function Cover_E_Diagram() {
  return (
    <SlideShell hideHeader>
      <div style={{ flex:1, display:'grid', gridTemplateRows:'1fr auto', paddingTop: 30 }}>
        <div style={{ display:'flex', alignItems:'center', gap: 24 }}>
          <div style={{ flex:1 }}>
            <div style={{ fontSize: 42, fontWeight: 700, lineHeight: 1.1, letterSpacing:'-0.02em' }}>
              Skew‑Aware<br/>Stratified Sampling
            </div>
            <Scribble w="70%" h={6} mb={6} c={W.lineLight} />
            <Scribble w="60%" h={6} mb={0} c={W.lineLight} />
          </div>
          <div style={{ flex: 1.1, display:'flex', alignItems:'center', justifyContent:'space-between', position:'relative' }}>
            {['SYS','BERN','KM20'].map((t, i) => (
              <React.Fragment key={t}>
                <div style={{
                  width: 110, height: 110, borderRadius: '50%',
                  border: `2px ${i===2?'solid':'dashed'} ${i===2?W.red:W.fg3}`,
                  display:'flex', alignItems:'center', justifyContent:'center',
                  fontFamily:'JetBrains Mono, monospace', fontSize: 16, fontWeight: 700,
                  color: i===2?W.red:W.fg2,
                  background: i===2?'#FEE2E2':W.bg,
                }}>{t}</div>
                {i<2 && <div style={{ flex:1, borderTop: `2px dashed ${W.fg3}`, marginTop: -2 }}/>}
              </React.Fragment>
            ))}
          </div>
        </div>
        <div style={{ borderTop: `2px solid ${W.ink}`, paddingTop: 16, display:'flex', justifyContent:'space-between' }}>
          <div>
            <div style={{ fontSize: 20, fontWeight: 700 }}>속도는벡터</div>
            <Scribble w={240} h={5} mb={0} c={W.lineLight}/>
          </div>
          <div style={{ fontFamily:'JetBrains Mono, monospace', fontSize: 11, color: W.fg3, alignSelf:'flex-end' }}>2026‑04‑30 · MIDTERM</div>
        </div>
      </div>
      <StickyNote top={70} right={80} rotate={-2} w={180}>방법론 진화 다이어그램을 표지에</StickyNote>
    </SlideShell>
  );
}

window.CoverVariations = [Cover_A_LeftAlign, Cover_B_Centered, Cover_C_BigNumber, Cover_D_Editorial, Cover_E_Diagram];
