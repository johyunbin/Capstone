/* global React, SlideShell, Scribble, Lorem, Box, FakeChart, FakeTable, Eyebrow, StickyNote, Squiggle, W, HAND */

// ═══════════════════════════════════════════════════════════════
// METHOD/BACKGROUND variations — 5
// ═══════════════════════════════════════════════════════════════

function Method_A_TwoCards() {
  return (
    <SlideShell secn="2." title="Exqutor — 두 갈래 방법론" page="4 / 12">
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap: 28 }}>
        {[
          ['ECQO','HNSW 인덱스가 있을 때','1~2 ms','정확한 cardinality'],
          ['Adaptive Sampling','HNSW 인덱스가 없을 때','~3.2×','No‑index 성능 개선']
        ].map(([n,c,big,d],i)=>(
          <div key={i} style={{ border: `1.5px dashed ${W.line}`, padding: 22 }}>
            <Eyebrow>{c}</Eyebrow>
            <div style={{ fontSize: 24, fontWeight: 700 }}>{n}</div>
            <Scribble w="80%" h={5} mb={6} c={W.lineLight}/>
            <Scribble w="60%" h={5} mb={20} c={W.lineLight}/>
            <div style={{ paddingTop: 14, borderTop: `1px dashed ${W.lineLight}`, display:'flex', alignItems:'baseline', gap: 10 }}>
              <div style={{ fontSize: 40, fontWeight: 700, color: W.red, fontFamily:'Inter, sans-serif' }}>{big}</div>
              <div style={{ fontSize: 12, color: W.fg2 }}>{d}</div>
            </div>
          </div>
        ))}
      </div>
      <div style={{ marginTop: 22, padding:'12px 18px', borderLeft: `3px solid ${W.red}`, background: W.bg2, fontSize: 14 }}>
        → No‑index path 에서 uniform sample 이 <Squiggle>skewed vector distribution</Squiggle> 을 대표할 수 있는가?
      </div>
      <StickyNote top={130} right={70} rotate={2} w={150}>두 카드 + 의문문 종결</StickyNote>
    </SlideShell>
  );
}

function Method_B_Tree() {
  return (
    <SlideShell secn="2." title="Exqutor 결정 트리" page="4 / 12">
      <svg viewBox="0 0 1100 360" style={{ width:'100%', height: 360 }}>
        <rect x="450" y="20" width="200" height="50" fill={W.bg} stroke={W.fg2} strokeDasharray="4 3"/>
        <text x="550" y="50" textAnchor="middle" fontSize="14" fontWeight="700" fontFamily="Kalam">vector range query</text>
        <line x1="550" y1="70" x2="280" y2="120" stroke={W.fg3} strokeWidth="1.2"/>
        <line x1="550" y1="70" x2="820" y2="120" stroke={W.fg3} strokeWidth="1.2"/>
        <text x="380" y="105" fontSize="12" fill={W.fg2} fontFamily="JetBrains Mono">HNSW 有</text>
        <text x="700" y="105" fontSize="12" fill={W.fg2} fontFamily="JetBrains Mono">HNSW 無</text>
        <rect x="180" y="120" width="200" height="60" fill={W.bg} stroke={W.fg2}/>
        <text x="280" y="148" textAnchor="middle" fontSize="16" fontWeight="700" fontFamily="Kalam">ECQO</text>
        <text x="280" y="168" textAnchor="middle" fontSize="11" fill={W.fg3} fontFamily="JetBrains Mono">1–2 ms · exact</text>
        <rect x="720" y="120" width="200" height="60" fill="#FEE2E2" stroke={W.red} strokeWidth="1.5"/>
        <text x="820" y="148" textAnchor="middle" fontSize="16" fontWeight="700" fill={W.red} fontFamily="Kalam">Adaptive Sampling</text>
        <text x="820" y="168" textAnchor="middle" fontSize="11" fill={W.fg3} fontFamily="JetBrains Mono">~3.2× speed‑up</text>
        <line x1="820" y1="180" x2="820" y2="230" stroke={W.red} strokeWidth="1.2" strokeDasharray="4 3"/>
        <rect x="660" y="240" width="320" height="80" fill={W.bg2} stroke={W.red} strokeDasharray="4 3"/>
        <text x="820" y="268" textAnchor="middle" fontSize="12" fill={W.red} fontWeight="700" fontFamily="JetBrains Mono">우리의 관심 영역</text>
        <text x="820" y="290" textAnchor="middle" fontSize="13" fontFamily="Kalam">uniform sample 이 skew 를 잡지 못함</text>
      </svg>
      <StickyNote top={120} right={70} rotate={-3} w={150}>트리 다이어그램으로 분기 강조</StickyNote>
    </SlideShell>
  );
}

function Method_C_Table() {
  return (
    <SlideShell secn="2." title="Exqutor: Methods & Limits" page="4 / 12">
      <div style={{ display:'grid', gridTemplateColumns:'1fr', gap: 0 }}>
        <div style={{ display:'grid', gridTemplateColumns:'140px 1fr 1fr 110px', gap: 16, padding:'10px 0', borderBottom: `2px solid ${W.ink}`, fontSize: 11, fontFamily:'JetBrains Mono, monospace', color: W.fg2, fontWeight: 700, letterSpacing:'0.1em', textTransform:'uppercase' }}>
          <div>METHOD</div><div>CONDITION</div><div>MECHANISM</div><div style={{textAlign:'right'}}>METRIC</div>
        </div>
        {[
          ['ECQO','HNSW 인덱스가 있을 때','HNSW range query 직접 실행','1–2 ms'],
          ['Adaptive Sampling','HNSW 인덱스가 없을 때','dynamic uniform sampling','~3.2×'],
          ['(this work)','단일 테이블 + skew','SYS → BERN → KM20','TBD'],
        ].map(([m,c,me,v],i)=>(
          <div key={i} style={{ display:'grid', gridTemplateColumns:'140px 1fr 1fr 110px', gap: 16, padding:'14px 0', borderBottom: `1px dashed ${W.lineLight}`, alignItems:'center', background: i===2?'#FEF9C3':'transparent' }}>
            <div style={{ fontSize: 16, fontWeight: 700, color: i===2?W.red:W.ink }}>{m}</div>
            <Scribble w="90%" h={5} mb={0} c={W.lineLight}/>
            <Scribble w="80%" h={5} mb={0} c={W.lineLight}/>
            <div style={{ fontSize: 18, fontWeight: 700, color: W.red, fontFamily:'Inter, sans-serif', textAlign:'right' }}>{v}</div>
          </div>
        ))}
      </div>
      <StickyNote bottom={100} right={70} rotate={3} w={170}>표 형식 · 자기 자리 노출</StickyNote>
    </SlideShell>
  );
}

function Method_D_Annotated() {
  return (
    <SlideShell secn="2." title="우리가 보는 곳" page="4 / 12">
      <div style={{ position:'relative', height: 380 }}>
        <Box w="100%" h={140} style={{ marginBottom: 24 }} fill={W.bg2}>
          <div style={{ textAlign:'center' }}>
            <div style={{ fontSize: 11, color: W.fg3, fontFamily:'JetBrains Mono', marginBottom: 6 }}>Exqutor</div>
            <div style={{ fontSize: 18, fontWeight: 700 }}>ECQO  +  Adaptive Sampling</div>
          </div>
        </Box>
        <div style={{ display:'flex', justifyContent:'center', marginBottom: 16 }}>
          <div style={{ fontSize: 32, color: W.red, fontFamily:'Kalam' }}>↓</div>
        </div>
        <Box w="70%" h={120} style={{ margin:'0 auto', borderColor: W.red, borderWidth: 2 }} fill="#FEE2E2">
          <div style={{ textAlign:'center' }}>
            <Eyebrow>본 연구의 범위</Eyebrow>
            <div style={{ fontSize: 18, fontWeight: 700, color: W.ink }}>단일 테이블 vector range query 의 No‑index sampling path</div>
          </div>
        </Box>
        <StickyNote top={20} right={20} rotate={3} w={170}>줌인 / 우리가 다루는 부분만 빨강</StickyNote>
      </div>
    </SlideShell>
  );
}

function Method_E_Sequence() {
  return (
    <SlideShell secn="2." title="기존 방법의 흐름" page="4 / 12">
      <div style={{ display:'flex', gap: 16, alignItems:'stretch', marginTop: 14 }}>
        {[
          ['01','Query 도착','vector range'],
          ['02','HNSW 체크','index 유무'],
          ['03','Estimator','ECQO / AS / fixed'],
          ['04','Plan 결정','join · scan'],
          ['05','실행','runtime'],
        ].map(([n,t,d],i)=>(
          <div key={i} style={{ flex:1, border: `1.5px dashed ${i===2?W.red:W.line}`, padding: 14, background: i===2?'#FEE2E2':W.bg }}>
            <div style={{ fontFamily:'JetBrains Mono, monospace', fontSize: 11, color: W.red, fontWeight: 700 }}>{n}</div>
            <div style={{ fontSize: 14, fontWeight: 700, marginTop: 8, marginBottom: 6 }}>{t}</div>
            <div style={{ fontSize: 11, color: W.fg3, fontFamily:'JetBrains Mono' }}>{d}</div>
          </div>
        ))}
      </div>
      <div style={{ marginTop: 32, display:'grid', gridTemplateColumns:'1fr 1fr', gap: 24 }}>
        <div>
          <Eyebrow>ECQO</Eyebrow>
          <Lorem lines={3} c={W.lineLight}/>
        </div>
        <div>
          <Eyebrow>Adaptive Sampling</Eyebrow>
          <Lorem lines={3} c={W.lineLight}/>
        </div>
      </div>
      <StickyNote top={130} right={70} rotate={-2} w={150}>5단계 시퀀스 + 상세</StickyNote>
    </SlideShell>
  );
}

window.MethodVariations = [Method_A_TwoCards, Method_B_Tree, Method_C_Table, Method_D_Annotated, Method_E_Sequence];

// ═══════════════════════════════════════════════════════════════
// RESULTS (CHART+TEXT) variations — 5
// ═══════════════════════════════════════════════════════════════

function Results_A_BigChart() {
  return (
    <SlideShell secn="4‑1." title="RQ1 — Q‑error vs Skew 지표" page="7 / 12">
      <div style={{ display:'grid', gridTemplateColumns:'1.4fr 1fr', gap: 28, height:'100%' }}>
        <FakeChart h={420} kind="heatmap" label="HEATMAP · 4×6"/>
        <div>
          <Eyebrow>주요 발견</Eyebrow>
          <ul style={{ margin:0, padding:0, listStyle:'none', display:'flex', flexDirection:'column', gap: 14, fontSize: 14 }}>
            {['글로벌·로컬 지표 모두 안정 상관 없음','24 조합 모두 |ρ| < 0.2','query‑side feature 만으로는 불충분'].map((t,i)=>(
              <li key={i}><span style={{ color: W.red, fontWeight: 700 }}>{['①','②','③'][i]}</span> {t}</li>
            ))}
          </ul>
          <div style={{ marginTop: 22, padding:'12px 14px', background: W.bg2, borderLeft: `3px solid ${W.red}`, fontSize: 13 }}>
            <Squiggle>negative result</Squiggle> — 사전 예측 불가, 본 연구의 출발점.
          </div>
        </div>
      </div>
      <StickyNote bottom={100} right={70} rotate={2} w={150}>큰 chart + 사이드 takeaway</StickyNote>
    </SlideShell>
  );
}

function Results_B_TableHero() {
  return (
    <SlideShell secn="4‑2." title="RQ2(1) — SYS vs BERN" page="8 / 12">
      <div style={{ display:'grid', gridTemplateColumns:'1.2fr 1fr', gap: 30 }}>
        <div>
          <FakeTable rows={7} cols={5} highlight={5}/>
          <div style={{ fontSize: 11, color: W.fg3, marginTop: 8, fontFamily:'JetBrains Mono' }}>표: Q‑error median, paired Wilcoxon, n=100.</div>
        </div>
        <div>
          <Eyebrow>Headline</Eyebrow>
          <div style={{ fontSize: 48, fontWeight: 700, color: W.red, fontFamily:'Inter, sans-serif', lineHeight: 1, letterSpacing:'-0.02em' }}>+9.6%</div>
          <div style={{ fontSize: 13, color: W.fg2, marginTop: 8 }}>s=0.5 에서 BERN 이 78/100 query 개선</div>
          <div style={{ height: 1, background: W.line, margin:'18px 0' }}/>
          <Lorem lines={4} c={W.lineLight}/>
        </div>
      </div>
      <StickyNote bottom={100} right={70} rotate={-2} w={150}>표가 영웅 · headline 옆</StickyNote>
    </SlideShell>
  );
}

function Results_C_GridStats() {
  const stats = [
    ['DEEP 1M','+1.64%','[+1.11, +2.18]'],
    ['DEEP 8M','+1.76%','[+0.65, +2.86]'],
    ['SIFT 1.5M','+3.07%','[+2.66, +3.48]'],
  ];
  return (
    <SlideShell secn="4‑4." title="External Validity — 3 데이터셋" page="10 / 12">
      <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap: 20, marginBottom: 28 }}>
        {stats.map(([n,v,ci])=>(
          <div key={n} style={{ border: `1.5px dashed ${W.line}`, padding: 22 }}>
            <div style={{ fontSize: 12, fontWeight: 700, color: W.fg2 }}>{n}</div>
            <div style={{ fontSize: 52, fontWeight: 700, color: W.red, fontFamily:'Inter, sans-serif', lineHeight: 1, marginTop: 10, letterSpacing:'-0.02em' }}>{v}</div>
            <div style={{ fontFamily:'JetBrains Mono', fontSize: 11, color: W.fg3, marginTop: 10 }}>CI {ci}</div>
            <Scribble w="80%" h={4} mb={0} c={W.lineLight}/>
          </div>
        ))}
      </div>
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap: 28 }}>
        <FakeChart h={170} kind="bars" label="CROSS‑DATASET BAR"/>
        <ul style={{ margin:0, padding:0, listStyle:'none', display:'flex', flexDirection:'column', gap: 8, fontSize: 13 }}>
          <li>① DEEP 1M ↔ 8M : CI 겹침 (CONSISTENT)</li>
          <li>② SIFT: 더 큰 개선폭 → skewed↑ ⇒ 효과↑</li>
          <li>③ 외적 타당성 확보</li>
        </ul>
      </div>
      <StickyNote bottom={70} right={70} rotate={3} w={160}>3 stat block + 차트 + 요약</StickyNote>
    </SlideShell>
  );
}

function Results_D_Callout() {
  return (
    <SlideShell secn="4‑3." title="RQ2(2) — KM20 Stratified" page="9 / 12">
      <div style={{ display:'flex', flexDirection:'column', justifyContent:'center', alignItems:'center', height:'100%', textAlign:'center' }}>
        <div style={{ fontSize: 11, color: W.red, fontFamily:'JetBrains Mono', letterSpacing:'0.16em', fontWeight: 700, marginBottom: 18 }}>
          5‑SEED · 95% CI · n=100
        </div>
        <div style={{ display:'flex', alignItems:'baseline', gap: 14 }}>
          <div style={{ fontSize: 30, color: W.fg3 }}>BERN</div>
          <div style={{ fontSize: 60, color: W.red, fontFamily:'Inter, sans-serif' }}>→</div>
          <div style={{ fontSize: 30, color: W.ink, fontWeight: 700 }}>KM20</div>
        </div>
        <div style={{ fontSize: 130, fontWeight: 700, color: W.red, fontFamily:'Inter, sans-serif', lineHeight: 1, letterSpacing:'-0.04em', marginTop: 14 }}>+1.64%</div>
        <div style={{ fontSize: 16, color: W.fg2, marginTop: 14, fontFamily:'JetBrains Mono' }}>CI [+1.11, +2.18] · 5/5 seed</div>
        <div style={{ marginTop: 28, padding:'12px 22px', background: W.bg2, borderLeft: `3px solid ${W.red}`, fontSize: 14, maxWidth: 720 }}>
          <Squiggle>vector‑space skew</Squiggle> 를 sample allocation 에 반영하는 첫 positive result.
        </div>
      </div>
      <StickyNote top={100} right={70} rotate={-2} w={150}>한 결과만 영웅화</StickyNote>
    </SlideShell>
  );
}

function Results_E_Mixed() {
  return (
    <SlideShell secn="4‑3." title="RQ2(2) — KM20 결과" page="9 / 12">
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap: 28 }}>
        <FakeChart h={300} kind="box" label="BOXPLOT · BERN vs KM20"/>
        <div>
          <Eyebrow>BERN 대비 KM20 효과</Eyebrow>
          <FakeTable rows={6} cols={4} highlight={1}/>
        </div>
      </div>
      <div style={{ marginTop: 18, display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap: 14 }}>
        {[['+1.64%','s=0.50'],['+2.62%','s=0.30'],['+8.93%','s=0.01']].map(([v,s],i)=>(
          <div key={i} style={{ padding:'10px 14px', border:`1px dashed ${W.line}` }}>
            <div style={{ fontSize: 24, fontWeight: 700, color: W.red, fontFamily:'Inter, sans-serif' }}>{v}</div>
            <div style={{ fontSize: 11, color: W.fg3, fontFamily:'JetBrains Mono' }}>{s}</div>
          </div>
        ))}
      </div>
      <StickyNote bottom={130} right={70} rotate={2} w={140}>차트+표+칩 통합</StickyNote>
    </SlideShell>
  );
}

window.ResultsVariations = [Results_A_BigChart, Results_B_TableHero, Results_C_GridStats, Results_D_Callout, Results_E_Mixed];

// ═══════════════════════════════════════════════════════════════
// SECTION DIVIDER variations — 5
// ═══════════════════════════════════════════════════════════════

function Divider_A_BigNumber() {
  return (
    <SlideShell hideHeader>
      <div style={{ flex:1, display:'flex', alignItems:'center' }}>
        <div>
          <div style={{ fontSize: 240, fontWeight: 700, color: W.red, fontFamily:'Inter, sans-serif', lineHeight: 0.9, letterSpacing:'-0.04em' }}>04</div>
          <div style={{ fontSize: 56, fontWeight: 700, marginTop: 8, letterSpacing:'-0.02em' }}>Experiments</div>
          <Scribble w={300} h={6} mb={0} c={W.lineLight}/>
        </div>
      </div>
      <StickyNote top={80} right={70} rotate={3} w={130}>거대 번호</StickyNote>
    </SlideShell>
  );
}

function Divider_B_Centered() {
  return (
    <SlideShell hideHeader>
      <div style={{ flex:1, display:'flex', flexDirection:'column', justifyContent:'center', alignItems:'center', textAlign:'center' }}>
        <div style={{ fontSize: 14, color: W.red, fontFamily:'JetBrains Mono', letterSpacing:'0.2em', fontWeight: 700 }}>SECTION 04</div>
        <div style={{ width: 80, height: 1, background: W.ink, margin:'24px 0' }}/>
        <div style={{ fontSize: 64, fontWeight: 700, letterSpacing:'-0.02em' }}>Experiments</div>
        <Scribble w={400} h={5} mb={4} c={W.lineLight}/>
        <Scribble w={300} h={5} mb={0} c={W.lineLight}/>
      </div>
      <StickyNote bottom={80} right={70} rotate={-2} w={140}>중앙 미니멀</StickyNote>
    </SlideShell>
  );
}

function Divider_C_RedFull() {
  return (
    <SlideShell hideHeader bg={W.red}>
      <div style={{ flex:1, display:'flex', flexDirection:'column', justifyContent:'flex-end', color:'#fff' }}>
        <div style={{ fontSize: 14, opacity: 0.8, fontFamily:'JetBrains Mono', letterSpacing:'0.2em' }}>04 — EXPERIMENTS</div>
        <div style={{ fontSize: 96, fontWeight: 700, lineHeight: 1.0, letterSpacing:'-0.02em', marginTop: 18 }}>RQ1 · RQ2 · RQ3</div>
      </div>
      <StickyNote top={80} right={70} rotate={2} w={150}>예외적 빨강 풀블리드</StickyNote>
    </SlideShell>
  );
}

function Divider_D_TOC() {
  return (
    <SlideShell hideHeader>
      <div style={{ flex:1, display:'flex', alignItems:'center', gap: 60 }}>
        <div style={{ flex: 1.2 }}>
          <div style={{ fontSize: 14, color: W.red, fontFamily:'JetBrains Mono', letterSpacing:'0.2em', fontWeight: 700, marginBottom: 14 }}>SECTION 04</div>
          <div style={{ fontSize: 72, fontWeight: 700, letterSpacing:'-0.02em' }}>Experiments</div>
          <Scribble w="60%" h={5} c={W.lineLight}/>
        </div>
        <div style={{ flex: 1, borderLeft: `1px dashed ${W.line}`, paddingLeft: 32 }}>
          {['RQ1 — Skew 지표','RQ2 — Sampling 비교','RQ2 — KM20 결과','외적 타당성'].map((t,i)=>(
            <div key={i} style={{ display:'flex', gap: 12, padding:'10px 0', borderBottom: `1px dashed ${W.lineLight}`, fontSize: 14 }}>
              <span style={{ fontFamily:'JetBrains Mono', color: W.red, fontWeight: 700 }}>4‑{i+1}</span>
              <span>{t}</span>
            </div>
          ))}
        </div>
      </div>
      <StickyNote bottom={80} right={70} rotate={-3} w={150}>섹션 타이틀 + 하위 목차</StickyNote>
    </SlideShell>
  );
}

function Divider_E_Quote() {
  return (
    <SlideShell hideHeader>
      <div style={{ flex:1, display:'flex', flexDirection:'column', justifyContent:'center' }}>
        <div style={{ fontSize: 14, color: W.red, fontFamily:'JetBrains Mono', letterSpacing:'0.2em', fontWeight: 700, marginBottom: 28 }}>04 / EXPERIMENTS</div>
        <div style={{ fontSize: 48, fontWeight: 700, lineHeight: 1.2, letterSpacing:'-0.02em', maxWidth: 1000 }}>
          "skewed vector space 에서<br/>uniform 은 충분치 않다."
        </div>
        <div style={{ fontSize: 14, color: W.fg3, marginTop: 28, fontFamily:'JetBrains Mono' }}>— 본 연구 가설</div>
      </div>
      <StickyNote bottom={70} right={70} rotate={3} w={140}>풀쿼트 디바이더</StickyNote>
    </SlideShell>
  );
}

window.DividerVariations = [Divider_A_BigNumber, Divider_B_Centered, Divider_C_RedFull, Divider_D_TOC, Divider_E_Quote];

// ═══════════════════════════════════════════════════════════════
// CLOSER variations — 5
// ═══════════════════════════════════════════════════════════════

function Closer_A_Big() {
  return (
    <SlideShell hideHeader>
      <div style={{ flex:1, display:'flex', flexDirection:'column', justifyContent:'center' }}>
        <div style={{ fontSize: 96, fontWeight: 700, letterSpacing:'-0.03em' }}>감사합니다.</div>
        <div style={{ fontSize: 48, fontWeight: 700, color: W.red, marginTop: 18 }}>Q & A</div>
        <div style={{ marginTop: 50, paddingTop: 18, borderTop: `2px solid ${W.ink}`, maxWidth: 480 }}>
          <div style={{ fontSize: 22, fontWeight: 700 }}>속도는벡터</div>
          <Scribble w="80%" h={5} c={W.lineLight}/>
          <Scribble w="60%" h={5} mb={0} c={W.lineLight}/>
        </div>
      </div>
      <StickyNote top={80} right={70} rotate={2} w={140}>거대 감사 + Q&amp;A</StickyNote>
    </SlideShell>
  );
}

function Closer_B_Recap() {
  return (
    <SlideShell secn="·" title="요약 & Q&A" page="12 / 12">
      <div style={{ display:'grid', gridTemplateColumns:'1.2fr 1fr', gap: 40 }}>
        <div>
          <Eyebrow>오늘의 결론</Eyebrow>
          {['Block bias 제거: SYS → BERN','Spatial allocation: KM20 stratified','외적 타당성: 3 dataset 검증'].map((t,i)=>(
            <div key={i} style={{ display:'flex', gap: 12, padding:'14px 0', borderBottom: `1px dashed ${W.lineLight}` }}>
              <div style={{ fontFamily:'JetBrains Mono', color: W.red, fontWeight: 700, fontSize: 14 }}>0{i+1}</div>
              <div style={{ fontSize: 16, fontWeight: 700 }}>{t}</div>
            </div>
          ))}
        </div>
        <div style={{ background: W.bg2, padding: 24, border: `1.5px dashed ${W.line}` }}>
          <div style={{ fontSize: 36, fontWeight: 700 }}>감사합니다.</div>
          <div style={{ fontSize: 24, fontWeight: 700, color: W.red, marginTop: 6 }}>Q & A</div>
          <div style={{ height: 1, background: W.line, margin:'20px 0' }}/>
          <div style={{ fontSize: 14, fontWeight: 700 }}>속도는벡터</div>
          <Scribble w="80%" h={4} mb={0} c={W.lineLight}/>
        </div>
      </div>
      <StickyNote bottom={100} right={70} rotate={-2} w={150}>요약 + 작은 thanks</StickyNote>
    </SlideShell>
  );
}

function Closer_C_Centered() {
  return (
    <SlideShell hideHeader>
      <div style={{ flex:1, display:'flex', flexDirection:'column', justifyContent:'center', alignItems:'center', textAlign:'center' }}>
        <div style={{ width: 1, height: 60, background: W.red, marginBottom: 28 }}/>
        <div style={{ fontSize: 14, color: W.red, fontFamily:'JetBrains Mono', letterSpacing:'0.2em', fontWeight: 700, marginBottom: 18 }}>END OF MIDTERM</div>
        <div style={{ fontSize: 80, fontWeight: 700, letterSpacing:'-0.02em' }}>감사합니다</div>
        <div style={{ fontSize: 32, color: W.red, marginTop: 8 }}>Q & A</div>
        <Scribble w={400} h={5} mb={0} c={W.lineLight} />
      </div>
      <StickyNote bottom={80} right={70} rotate={3} w={140}>중앙 정렬 대칭</StickyNote>
    </SlideShell>
  );
}

function Closer_D_Contact() {
  return (
    <SlideShell hideHeader>
      <div style={{ flex:1, display:'grid', gridTemplateRows:'1fr auto' }}>
        <div style={{ display:'flex', alignItems:'center' }}>
          <div style={{ fontSize: 120, fontWeight: 700, lineHeight: 1, letterSpacing:'-0.03em' }}>Q & A</div>
        </div>
        <div style={{ borderTop: `2px solid ${W.ink}`, paddingTop: 22, display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap: 30 }}>
          {[
            ['속도는벡터','박세은 · 강재현 · 조현빈 · 이동욱'],
            ['지도','박광현 · 임채림 · 박성원'],
            ['references','arXiv:2512.09695v2'],
          ].map(([h,b],i)=>(
            <div key={i}>
              <Eyebrow>{h}</Eyebrow>
              <Scribble w="90%" h={5} c={W.lineLight}/>
              <Scribble w="70%" h={5} c={W.lineLight}/>
            </div>
          ))}
        </div>
      </div>
      <StickyNote top={80} right={70} rotate={-2} w={150}>거대 Q&amp;A + 연락 푸터</StickyNote>
    </SlideShell>
  );
}

function Closer_E_NextSteps() {
  return (
    <SlideShell secn="·" title="감사합니다 — 다음 단계" page="12 / 12">
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap: 32, height:'100%' }}>
        <div style={{ display:'flex', flexDirection:'column', justifyContent:'center' }}>
          <div style={{ fontSize: 60, fontWeight: 700, letterSpacing:'-0.02em' }}>감사합니다.</div>
          <div style={{ fontSize: 24, color: W.red, marginTop: 4, fontWeight: 700 }}>Q & A</div>
          <Scribble w="60%" h={5} mb={4} c={W.lineLight}/>
        </div>
        <div>
          <Eyebrow>최종 발표까지</Eyebrow>
          {['RQ3 Offline pilot','Weight‑based 후보 (KDE / Distance shell)','민감도 분석 (K, sample_size)','최종 보고서 v2'].map((t,i)=>(
            <div key={i} style={{ display:'flex', gap: 12, padding:'10px 0', borderBottom: `1px dashed ${W.lineLight}`, fontSize: 13 }}>
              <span style={{ fontFamily:'JetBrains Mono', color: W.red, fontWeight: 700 }}>W{i+5}</span>
              <span>{t}</span>
            </div>
          ))}
        </div>
      </div>
      <StickyNote bottom={100} right={70} rotate={2} w={150}>닫으면서 다음 단계</StickyNote>
    </SlideShell>
  );
}

window.CloserVariations = [Closer_A_Big, Closer_B_Recap, Closer_C_Centered, Closer_D_Contact, Closer_E_NextSteps];
