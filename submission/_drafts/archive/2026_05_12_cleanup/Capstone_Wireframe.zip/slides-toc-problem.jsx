/* global React, SlideShell, Scribble, Lorem, Box, FakeChart, FakeTable, Eyebrow, StickyNote, Squiggle, W, HAND */

// ═══════════════════════════════════════════════════════════════
// TOC variations — 5
// ═══════════════════════════════════════════════════════════════
const TOC_ITEMS = [
  ['01','Problem','Vector Cardinality 의 사각지대','03'],
  ['02','Background','Exqutor 방법론과 한계','04'],
  ['03','Approach','Skew‑Aware Stratified Sampling','06'],
  ['04','Experiments','RQ1 · RQ2 · RQ3','07'],
  ['05','Plan','진행 현황 및 향후 계획','11'],
];

function TOC_A_Classic() {
  return (
    <SlideShell title="Table of Contents" page="2 / 12">
      <div style={{ display:'grid', gridTemplateColumns:'72px 1fr 80px', columnGap: 24 }}>
        {TOC_ITEMS.map((it,i)=>(
          <React.Fragment key={i}>
            <div style={{ padding:'18px 0', borderTop: i===0?`2px solid ${W.ink}`:`1px dashed ${W.line}`, fontFamily:'JetBrains Mono, monospace', fontSize: 22, fontWeight:700, color: W.red }}>{it[0]}</div>
            <div style={{ padding:'18px 0', borderTop: i===0?`2px solid ${W.ink}`:`1px dashed ${W.line}` }}>
              <div style={{ fontSize: 22, fontWeight: 700 }}>{it[1]}</div>
              <Scribble w="70%" h={5} mb={0} c={W.lineLight}/>
            </div>
            <div style={{ padding:'18px 0', borderTop: i===0?`2px solid ${W.ink}`:`1px dashed ${W.line}`, fontFamily:'JetBrains Mono, monospace', fontSize: 12, color: W.fg3, alignSelf:'center' }}>p.{it[3]}</div>
          </React.Fragment>
        ))}
      </div>
      <StickyNote top={120} right={70} rotate={2} w={150}>표 형식, 챕터 번호 좌측</StickyNote>
    </SlideShell>
  );
}

function TOC_B_Vertical() {
  return (
    <SlideShell title="Contents" page="2 / 12">
      <div style={{ display:'flex', gap: 18, marginTop: 20 }}>
        {TOC_ITEMS.map((it,i)=>(
          <div key={i} style={{ flex:1, borderTop: `3px solid ${i===0?W.red:W.line}`, paddingTop: 16 }}>
            <div style={{ fontFamily:'JetBrains Mono, monospace', fontSize: 11, color: W.red, fontWeight:700 }}>{it[0]}</div>
            <div style={{ fontSize: 18, fontWeight:700, marginTop: 8, marginBottom: 12, lineHeight: 1.2 }}>{it[1]}</div>
            <Scribble w="100%" h={5} c={W.lineLight}/>
            <Scribble w="80%" h={5} c={W.lineLight}/>
            <Scribble w="60%" h={5} c={W.lineLight}/>
            <div style={{ fontFamily:'JetBrains Mono, monospace', fontSize: 11, color: W.fg3, marginTop: 16 }}>p.{it[3]}</div>
          </div>
        ))}
      </div>
      <StickyNote top={130} right={80} rotate={-2} w={150}>5 컬럼 · 동등 가중</StickyNote>
    </SlideShell>
  );
}

function TOC_C_BigNumbers() {
  return (
    <SlideShell title="Today" page="2 / 12">
      <div style={{ display:'flex', flexDirection:'column', gap: 4 }}>
        {TOC_ITEMS.map((it,i)=>(
          <div key={i} style={{ display:'grid', gridTemplateColumns:'120px 1fr', gap: 24, padding:'12px 0', borderBottom: `1px dashed ${W.lineLight}` }}>
            <div style={{ fontFamily:'Inter, sans-serif', fontSize: 56, fontWeight:700, color: i===0?W.red:W.lineLight, lineHeight: 1, letterSpacing:'-0.03em' }}>{it[0]}</div>
            <div style={{ alignSelf:'center' }}>
              <div style={{ fontSize: 22, fontWeight: 700 }}>{it[1]}</div>
              <Scribble w="50%" h={5} mb={0} c={W.lineLight}/>
            </div>
          </div>
        ))}
      </div>
      <StickyNote top={140} right={80} rotate={2} w={150}>큰 번호로 시각 리듬</StickyNote>
    </SlideShell>
  );
}

function TOC_D_Map() {
  return (
    <SlideShell title="Roadmap of Talk" page="2 / 12">
      <svg viewBox="0 0 1100 380" style={{ width:'100%', height: 380 }}>
        <line x1="40" y1="200" x2="1060" y2="200" stroke={W.fg3} strokeWidth="1.2" strokeDasharray="4 3"/>
        {TOC_ITEMS.map((it,i)=>{
          const x = 80 + i * 235;
          return (
            <g key={i}>
              <circle cx={x} cy="200" r="14" fill={i<2?W.red:W.bg} stroke={W.red} strokeWidth="1.5"/>
              <text x={x} y="205" textAnchor="middle" fontSize="12" fontWeight="700" fill={i<2?W.bg:W.red} fontFamily="JetBrains Mono, monospace">{it[0]}</text>
              <text x={x} y={i%2?260:165} textAnchor="middle" fontSize="18" fontWeight="700" fill={W.ink} fontFamily="Kalam, cursive">{it[1]}</text>
              <text x={x} y={i%2?282:143} textAnchor="middle" fontSize="11" fill={W.fg3} fontFamily="JetBrains Mono, monospace">p.{it[3]}</text>
            </g>
          );
        })}
      </svg>
      <StickyNote top={120} right={80} rotate={3} w={170}>여정 비유 · 진행 위치 표시</StickyNote>
    </SlideShell>
  );
}

function TOC_E_TwoColumn() {
  return (
    <SlideShell title="Today's Outline" page="2 / 12">
      <div style={{ display:'grid', gridTemplateColumns:'1.4fr 1fr', gap: 60, height:'100%' }}>
        <div>
          {TOC_ITEMS.map((it,i)=>(
            <div key={i} style={{ display:'grid', gridTemplateColumns:'40px 1fr 50px', gap: 14, alignItems:'center', padding:'14px 0', borderBottom: `1px dashed ${W.lineLight}` }}>
              <div style={{ fontFamily:'JetBrains Mono, monospace', fontSize: 14, color: W.red, fontWeight:700 }}>{it[0]}</div>
              <div style={{ fontSize: 18, fontWeight: 700 }}>{it[1]}</div>
              <div style={{ fontFamily:'JetBrains Mono, monospace', fontSize: 11, color: W.fg3, textAlign:'right' }}>p.{it[3]}</div>
            </div>
          ))}
        </div>
        <div style={{ background: W.bg2, padding: 24, border: `1px dashed ${W.line}` }}>
          <Eyebrow>오늘의 주제</Eyebrow>
          <div style={{ fontSize: 20, fontWeight: 700, lineHeight: 1.3, marginBottom: 14 }}>vector range query 의 cardinality 추정</div>
          <Lorem lines={4} c={W.line}/>
          <div style={{ marginTop: 16, padding: '10px 12px', background: W.bg, border: `1px solid ${W.red}` }}>
            <div style={{ fontSize: 11, fontFamily:'JetBrains Mono, monospace', color: W.red, fontWeight: 700, marginBottom: 6 }}>KEY RESULT</div>
            <div style={{ fontSize: 32, fontWeight: 700, color: W.red, fontFamily: 'Inter, sans-serif' }}>+1.64 ~ +3.07%</div>
          </div>
        </div>
      </div>
      <StickyNote bottom={70} right={80} rotate={-3} w={160}>좌: 목차 / 우: 컨텍스트 박스</StickyNote>
    </SlideShell>
  );
}

window.TOCVariations = [TOC_A_Classic, TOC_B_Vertical, TOC_C_BigNumbers, TOC_D_Map, TOC_E_TwoColumn];

// ═══════════════════════════════════════════════════════════════
// PROBLEM variations — 5
// ═══════════════════════════════════════════════════════════════

function Problem_A_Compare() {
  return (
    <SlideShell secn="1." title="Vector Cardinality 추정의 사각지대" page="3 / 12">
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap: 36 }}>
        <div>
          <Eyebrow>기존 — 고정 비율 추정</Eyebrow>
          {[['pgvector','33.3%'],['VBASE','50.0%'],['DuckDB','100%']].map(([n,v])=>(
            <div key={n} style={{ display:'flex', justifyContent:'space-between', alignItems:'baseline', padding:'12px 0', borderBottom: `1px dashed ${W.lineLight}` }}>
              <div style={{ fontSize: 18, fontWeight: 700 }}>{n}</div>
              <div style={{ fontSize: 28, fontWeight: 700, color: W.red, fontFamily:'Inter, sans-serif' }}>{v}</div>
            </div>
          ))}
        </div>
        <div>
          <Eyebrow>실제 — query 별 분포</Eyebrow>
          <div style={{ marginBottom: 14 }}>
            <Scribble w="100%" h={6} c={W.line}/>
            <Scribble w="92%" h={6} c={W.line}/>
            <Scribble w="80%" h={6} c={W.line}/>
            <Scribble w="60%" h={6} c={W.lineLight}/>
          </div>
          <div style={{ borderLeft: `3px solid ${W.red}`, paddingLeft: 14, marginTop: 16, fontSize: 14, lineHeight: 1.5 }}>
            <Squiggle>고정 비율 추정으로는 query‑dependent vector selectivity 를 설명할 수 없다.</Squiggle>
          </div>
        </div>
      </div>
      <StickyNote bottom={70} right={80} rotate={2} w={160}>2단 비교 · 좌 시스템 / 우 인용</StickyNote>
    </SlideShell>
  );
}

function Problem_B_BigStat() {
  return (
    <SlideShell secn="1." title="Problem" page="3 / 12">
      <div style={{ marginBottom: 28 }}>
        <Eyebrow>실제 vector range query 의 selectivity</Eyebrow>
        <div style={{ display:'flex', alignItems:'baseline', gap: 18 }}>
          <div style={{ fontSize: 96, fontWeight: 700, fontFamily:'Inter, sans-serif', color: W.red, lineHeight:1, letterSpacing:'-0.03em' }}>0.001%</div>
          <div style={{ fontSize: 36, color: W.fg3, fontFamily:'Inter, sans-serif' }}>~</div>
          <div style={{ fontSize: 96, fontWeight: 700, fontFamily:'Inter, sans-serif', color: W.red, lineHeight:1, letterSpacing:'-0.03em' }}>100%</div>
        </div>
        <div style={{ fontSize: 14, color: W.fg2, marginTop: 10 }}>그러나 기존 optimizer 는 33.3% / 50% / 100% 같은 고정 비율로 추정한다.</div>
      </div>
      <div style={{ borderTop: `2px solid ${W.ink}`, paddingTop: 18, display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap: 24 }}>
        {['잘못된 cardinality','왜곡된 join 순서','비효율적 실행 계획'].map((t,i)=>(
          <div key={i}>
            <div style={{ fontFamily:'JetBrains Mono, monospace', fontSize: 12, color: W.red, fontWeight: 700 }}>0{i+1} →</div>
            <div style={{ fontSize: 16, fontWeight: 700, marginTop: 6 }}>{t}</div>
            <Scribble w="80%" h={5} mb={4} c={W.lineLight}/>
            <Scribble w="60%" h={5} mb={0} c={W.lineLight}/>
          </div>
        ))}
      </div>
      <StickyNote top={130} right={80} rotate={-2} w={150}>큰 숫자로 갭 강조</StickyNote>
    </SlideShell>
  );
}

function Problem_C_Distribution() {
  return (
    <SlideShell secn="1." title="고정 비율로는 잡히지 않는다" page="3 / 12">
      <div style={{ display:'grid', gridTemplateColumns:'1.3fr 1fr', gap: 36, alignItems:'start' }}>
        <FakeChart h={320} kind="bars" label="QUERY SELECTIVITY DISTRIBUTION"/>
        <div>
          <Eyebrow>관찰</Eyebrow>
          <ul style={{ margin:0, padding:0, listStyle:'none', display:'flex', flexDirection:'column', gap: 12, fontSize: 14 }}>
            {['실제 선택도 0.001 ~ 100%','query‑adaptive 분포','고정 비율 → 추정 오차 누적'].map((t,i)=>(
              <li key={i}>
                <span style={{ color: W.red, fontWeight: 700 }}>①②③'[i]'</span> {t}
              </li>
            ))}
          </ul>
          <div style={{ marginTop: 18, padding: 14, background: W.bg2, borderLeft: `3px solid ${W.red}`, fontSize: 13 }}>
            <Squiggle>query‑dependent vector selectivity</Squiggle> 를 모델링해야 한다.
          </div>
        </div>
      </div>
      <StickyNote top={120} right={70} rotate={2} w={140}>분포 시각화 우선</StickyNote>
    </SlideShell>
  );
}

function Problem_D_Question() {
  return (
    <SlideShell secn="1." title=" " page="3 / 12">
      <div style={{ display:'flex', flexDirection:'column', justifyContent:'center', height:'100%' }}>
        <div style={{ fontSize: 14, color: W.red, fontFamily:'JetBrains Mono, monospace', letterSpacing: '0.18em', marginBottom: 18, fontWeight: 700 }}>QUESTION</div>
        <div style={{ fontSize: 56, fontWeight: 700, lineHeight: 1.15, letterSpacing: '-0.02em', maxWidth: 1000 }}>
          왜 우리는 <Squiggle>vector query 의 선택도</Squiggle><br/>를 사전에 알 수 없는가?
        </div>
        <div style={{ height: 2, background: W.ink, width: 200, margin: '36px 0 18px' }}/>
        <div style={{ fontSize: 18, color: W.fg2, maxWidth: 850, lineHeight: 1.5 }}>
          기존 optimizer 는 실제 분포를 보지 않고 33.3% · 50% · 100% 같은 고정 상수로 추정한다.
        </div>
      </div>
      <StickyNote top={100} right={80} rotate={3} w={160}>한 문장 질문 슬라이드</StickyNote>
    </SlideShell>
  );
}

function Problem_E_Diagram() {
  return (
    <SlideShell secn="1." title="Cardinality 추정의 흐름과 사각지대" page="3 / 12">
      <div style={{ display:'flex', flexDirection:'column', gap: 18, marginTop: 6 }}>
        <div style={{ display:'flex', gap: 14, alignItems:'center' }}>
          {['Query','Optimizer','고정 비율','Plan','Execution'].map((t,i)=>(
            <React.Fragment key={i}>
              <div style={{ flex: i===2?1.2:1, padding:'14px 16px', border: `1.5px ${i===2?'solid':'dashed'} ${i===2?W.red:W.line}`, background: i===2?'#FEE2E2':W.bg, textAlign:'center', fontSize: 14, fontWeight: 700, color: i===2?W.red:W.ink, fontFamily: 'JetBrains Mono, monospace' }}>{t}</div>
              {i<4 && <div style={{ width: 14, color: W.fg3, fontSize: 18, textAlign:'center' }}>→</div>}
            </React.Fragment>
          ))}
        </div>
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap: 36, marginTop: 24 }}>
          <div>
            <Eyebrow>여기가 사각지대</Eyebrow>
            <div style={{ fontSize: 16, fontWeight: 700, marginBottom: 8 }}>vector 공간 분포 미반영</div>
            <Lorem lines={3} c={W.lineLight}/>
          </div>
          <div>
            <Eyebrow>결과</Eyebrow>
            <div style={{ fontSize: 16, fontWeight: 700, marginBottom: 8 }}>plan 선택 왜곡 · 비효율</div>
            <Lorem lines={3} c={W.lineLight}/>
          </div>
        </div>
      </div>
      <StickyNote top={120} right={70} rotate={-2} w={150}>파이프라인 다이어그램</StickyNote>
    </SlideShell>
  );
}

window.ProblemVariations = [Problem_A_Compare, Problem_B_BigStat, Problem_C_Distribution, Problem_D_Question, Problem_E_Diagram];
