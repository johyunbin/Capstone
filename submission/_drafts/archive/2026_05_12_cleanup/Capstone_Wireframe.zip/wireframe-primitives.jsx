/* global React */
// ─── Wireframe primitives — sketchy low-fi blocks ────────────
// Use these for ALL wireframes. Single source of style.

const W = {
  ink: '#171717',
  fg2: '#404040',
  fg3: '#737373',
  fg4: '#A3A3A3',
  line: '#D4D4D4',
  lineLight: '#E7E5E4',
  red: '#DC2626',
  bg: '#FFFFFF',
  bg2: '#FAFAF9',
  paper: '#FBFBF8',
};

// Hand-drawn font stack — Kalam loaded in head
const HAND = '"Kalam", "Caveat", "Comic Sans MS", cursive';
const HAND_BOLD = '"Kalam", "Caveat", "Comic Sans MS", cursive';

// Slide chrome (shared) ────────────────────────────────────────
function SlideShell({ secn, title, page = '— /—', total = 12, children, hideHeader = false, paddingTop = 22, bg = '#FFFFFF' }) {
  return (
    <div style={{
      width: 1280, height: 720, background: bg,
      padding: '56px 72px 44px',
      boxSizing: 'border-box',
      position: 'relative',
      display: 'flex', flexDirection: 'column',
      fontFamily: HAND,
      color: W.ink,
      overflow: 'hidden',
    }}>
      {/* eyebrow */}
      <div style={{ width: 158, height: 2, background: W.red, marginBottom: 6 }} />
      <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.16em', textTransform: 'uppercase', color: W.red, fontFamily: 'JetBrains Mono, monospace' }}>
        CAPSTONE 2026‑1 / MIDTERM / 연세대학교
      </div>

      {!hideHeader && (
        <div style={{
          display: 'flex', justifyContent: 'space-between', alignItems: 'baseline',
          marginTop: 22, paddingBottom: 14, borderBottom: `1px dashed ${W.line}`,
        }}>
          <div>
            {secn && <span style={{ fontSize: 16, fontWeight: 700, color: W.red, marginRight: 8, fontFamily: HAND }}>{secn}</span>}
            <span style={{ fontSize: 28, fontWeight: 700, color: W.ink, letterSpacing: '-0.01em', fontFamily: HAND_BOLD }}>{title}</span>
          </div>
          <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 13, color: W.fg3 }}>{page}</div>
        </div>
      )}

      <div style={{ flex: 1, paddingTop, minHeight: 0 }}>{children}</div>

      <div style={{
        position: 'absolute', left: 72, right: 72, bottom: 18,
        display: 'flex', justifyContent: 'space-between',
        fontFamily: 'JetBrains Mono, monospace', fontSize: 11, color: W.fg3,
        paddingTop: 8, borderTop: `1px dashed ${W.line}`,
      }}>
        <span>속도는벡터</span>
        <span>WIREFRAME · v0</span>
      </div>
    </div>
  );
}

// Scribble line — fake text body, single line ─────────────────
function Scribble({ w = '100%', h = 8, c = W.line, mb = 8, dashed = false, op = 1 }) {
  return (
    <div style={{
      width: w, height: h, background: dashed ? 'transparent' : c,
      borderTop: dashed ? `2px dashed ${c}` : 'none',
      marginBottom: mb, borderRadius: 2, opacity: op,
    }} />
  );
}

// Lorem block ─ stacked scribble lines mimicking paragraph ────
function Lorem({ lines = 3, w = '100%', last = '60%', gap = 10, c = W.lineLight, h = 7 }) {
  return (
    <div>
      {Array.from({ length: lines }).map((_, i) => (
        <Scribble key={i} w={i === lines - 1 ? last : w} h={h} c={c} mb={gap} />
      ))}
    </div>
  );
}

// Sketchy box (dashed border placeholder) ─────────────────────
function Box({ w = '100%', h = 100, label, children, dashed = true, style = {}, fill = 'transparent', diagonal = false }) {
  return (
    <div style={{
      width: w, height: h,
      border: `1.5px ${dashed ? 'dashed' : 'solid'} ${W.line}`,
      background: fill,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      color: W.fg3, fontSize: 13, fontFamily: HAND,
      position: 'relative',
      backgroundImage: diagonal
        ? `repeating-linear-gradient(135deg, transparent 0 8px, ${W.lineLight} 8px 9px)`
        : 'none',
      ...style,
    }}>
      {label && <span style={{ background: W.bg, padding: '2px 8px', color: W.fg3 }}>{label}</span>}
      {children}
    </div>
  );
}

// Fake chart frame ─ axis + dashed area ───────────────────────
function FakeChart({ w = '100%', h = 200, kind = 'bars', label = 'CHART' }) {
  const charts = {
    bars: (
      <svg viewBox="0 0 200 100" preserveAspectRatio="none" style={{ width: '100%', height: '100%' }}>
        <line x1="10" y1="90" x2="195" y2="90" stroke={W.fg4} strokeWidth="0.6" />
        <line x1="10" y1="5" x2="10" y2="90" stroke={W.fg4} strokeWidth="0.6" />
        {[20, 45, 30, 60, 35, 70].map((v, i) => (
          <rect key={i} x={20 + i * 28} y={90 - v} width="18" height={v} fill={i % 2 ? W.lineLight : W.fg4} />
        ))}
      </svg>
    ),
    scatter: (
      <svg viewBox="0 0 200 100" preserveAspectRatio="none" style={{ width: '100%', height: '100%' }}>
        <line x1="10" y1="90" x2="195" y2="90" stroke={W.fg4} strokeWidth="0.6" />
        <line x1="10" y1="5" x2="10" y2="90" stroke={W.fg4} strokeWidth="0.6" />
        {Array.from({ length: 28 }).map((_, i) => (
          <circle key={i} cx={15 + (i * 7) % 175 + (i % 3) * 4} cy={20 + (i * 11) % 65} r="1.6" fill={i % 4 === 0 ? W.red : W.fg3} opacity="0.7" />
        ))}
      </svg>
    ),
    line: (
      <svg viewBox="0 0 200 100" preserveAspectRatio="none" style={{ width: '100%', height: '100%' }}>
        <line x1="10" y1="90" x2="195" y2="90" stroke={W.fg4} strokeWidth="0.6" />
        <line x1="10" y1="5" x2="10" y2="90" stroke={W.fg4} strokeWidth="0.6" />
        <polyline points="15,70 35,55 60,62 85,40 110,45 140,28 170,22 190,18" stroke={W.red} strokeWidth="1.2" fill="none" />
        <polyline points="15,80 35,72 60,75 85,68 110,62 140,55 170,50 190,48" stroke={W.fg3} strokeWidth="1.2" fill="none" strokeDasharray="3 2" />
      </svg>
    ),
    box: (
      <svg viewBox="0 0 200 100" preserveAspectRatio="none" style={{ width: '100%', height: '100%' }}>
        <line x1="10" y1="90" x2="195" y2="90" stroke={W.fg4} strokeWidth="0.6" />
        {[30, 70, 110, 150].map((x, i) => (
          <g key={i}>
            <line x1={x + 10} y1="20" x2={x + 10} y2="80" stroke={W.fg3} strokeWidth="0.6" />
            <rect x={x} y={i % 2 ? 35 : 30} width="20" height={i % 2 ? 30 : 40} fill={i % 2 ? W.fg4 : W.lineLight} stroke={W.fg3} strokeWidth="0.6" />
            <line x1={x} y1={i % 2 ? 50 : 50} x2={x + 20} y2={i % 2 ? 50 : 50} stroke={W.red} strokeWidth="1" />
          </g>
        ))}
      </svg>
    ),
    heatmap: (
      <svg viewBox="0 0 200 100" preserveAspectRatio="none" style={{ width: '100%', height: '100%' }}>
        {Array.from({ length: 4 }).map((_, r) =>
          Array.from({ length: 6 }).map((_, c) => {
            const v = ((r * 7 + c * 5 + 3) % 9) / 9;
            const shade = Math.round(220 - v * 80);
            return <rect key={`${r}-${c}`} x={20 + c * 28} y={10 + r * 20} width="26" height="18" fill={`rgb(${shade},${shade},${shade})`} stroke={W.bg} strokeWidth="0.6" />;
          })
        )}
      </svg>
    ),
  };
  return (
    <div style={{
      width: w, height: h,
      border: `1.5px dashed ${W.line}`,
      padding: 10, boxSizing: 'border-box',
      position: 'relative',
    }}>
      {charts[kind]}
      <div style={{
        position: 'absolute', top: 6, left: 8,
        fontSize: 10, fontFamily: 'JetBrains Mono, monospace',
        color: W.fg3, letterSpacing: '0.1em',
      }}>[{label}]</div>
    </div>
  );
}

// Sketchy table placeholder ─────────────────────────────────────
function FakeTable({ rows = 5, cols = 4, highlight = -1, w = '100%' }) {
  return (
    <div style={{ width: w, fontFamily: HAND, fontSize: 12 }}>
      {Array.from({ length: rows }).map((_, r) => (
        <div key={r} style={{
          display: 'grid', gridTemplateColumns: `repeat(${cols}, 1fr)`,
          padding: '8px 4px', gap: 8,
          borderBottom: r === 0 ? `2px solid ${W.ink}` : `1px solid ${W.lineLight}`,
          background: r === highlight ? '#FEE2E2' : 'transparent',
        }}>
          {Array.from({ length: cols }).map((_, c) => (
            <div key={c} style={{
              height: r === 0 ? 8 : 6,
              background: r === 0 ? W.fg2 : (c === 0 ? W.fg4 : W.lineLight),
              width: c === 0 ? '60%' : (c === cols - 1 ? '50%' : '70%'),
              borderRadius: 1,
            }} />
          ))}
        </div>
      ))}
    </div>
  );
}

// Eyebrow label
function Eyebrow({ children, c = W.red }) {
  return (
    <div style={{
      fontSize: 10, fontWeight: 700, letterSpacing: '0.14em',
      textTransform: 'uppercase', color: c,
      fontFamily: 'JetBrains Mono, monospace',
      marginBottom: 8,
    }}>{children}</div>
  );
}

// Sticky note (annotation) ─────────────────────────────────────
function StickyNote({ children, rotate = -1, top, right, left, bottom, w = 180 }) {
  return (
    <div style={{
      position: 'absolute',
      top, right, left, bottom,
      width: w, padding: '10px 12px',
      background: '#FEF9C3',
      border: `1px solid #FACC15`,
      transform: `rotate(${rotate}deg)`,
      fontFamily: HAND,
      fontSize: 12,
      color: '#713F12',
      lineHeight: 1.4,
      boxShadow: '0 2px 4px rgba(0,0,0,0.06)',
      zIndex: 5,
    }}>{children}</div>
  );
}

// Squiggle underline (highlight)
function Squiggle({ children, color = W.red }) {
  return (
    <span style={{
      backgroundImage: `url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 60 6'><path d='M0 3 Q 7.5 0 15 3 T 30 3 T 45 3 T 60 3' stroke='${encodeURIComponent(color)}' stroke-width='1.5' fill='none'/></svg>")`,
      backgroundRepeat: 'repeat-x',
      backgroundPosition: 'bottom',
      backgroundSize: '60px 4px',
      paddingBottom: 4,
    }}>{children}</span>
  );
}

// Hand-drawn arrow
function Arrow({ from, to, color = W.fg2, dashed = false }) {
  return (
    <svg style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%', pointerEvents: 'none', zIndex: 4 }}>
      <defs>
        <marker id="arr-head" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="6" markerHeight="6" orient="auto">
          <path d="M0,0 L10,5 L0,10 z" fill={color} />
        </marker>
      </defs>
      <line x1={from[0]} y1={from[1]} x2={to[0]} y2={to[1]}
        stroke={color} strokeWidth="1.5"
        strokeDasharray={dashed ? "4 3" : "none"}
        markerEnd="url(#arr-head)" />
    </svg>
  );
}

Object.assign(window, {
  W, HAND, HAND_BOLD,
  SlideShell, Scribble, Lorem, Box, FakeChart, FakeTable, Eyebrow, StickyNote, Squiggle, Arrow,
});
